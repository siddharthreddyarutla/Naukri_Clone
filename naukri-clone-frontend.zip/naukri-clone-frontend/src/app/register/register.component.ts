import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpEvent, HttpEventType } from '@angular/common/http';
import { ServicesService } from '../services.service';
import { saveAs } from 'file-saver'
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  constructor(private router: Router, private getData: ServicesService) { }
  candidate_register = {
    names: '',
    gender: '',
    phone: '',
    email: '',
    password: '',
    noticePeriod: '',
    resume: '',
    role: 'candidate',
  };


  filenames: string[] = [];
  fileStatus = { status: '', requestType: '', percent: 0 };

  back() {
    this.router.navigate(['/']);
  }

  register(data: any) {
    this.getData
      .candidateRegister(this.candidate_register)
      .subscribe((response) => {
        console.log(response);
        alert('Registered Successfully');
        this.router.navigate(['/']);
      });
  }

  onUploadFiles(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = input.files;
    console.log(files);
    const formData = new FormData();
    if (files) { for (let i = 0; i < files.length; i++) { formData.append('files', files[i], files[i].name); } }


    this.getData.upload(formData).subscribe(
      (event) => {
        console.log(event);
        this.resportProgress(event);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
      }
    );
  }

  private resportProgress(httpEvent: HttpEvent<string[] | Blob>): void {
    switch (httpEvent.type) {
      case HttpEventType.UploadProgress:
        this.updateStatus(httpEvent.loaded, httpEvent.total!, 'Uploading... ');
        break;
      case HttpEventType.DownloadProgress:
        this.updateStatus(
          httpEvent.loaded,
          httpEvent.total!,
          'Downloading... '
        );
        break;
      case HttpEventType.ResponseHeader:
        console.log('Header returned', httpEvent);
        break;
      case HttpEventType.Response: if (httpEvent.body instanceof Array) { this.fileStatus.status = 'done'; for (const filename of httpEvent.body) { this.filenames.unshift(filename); } } else { saveAs(new File([httpEvent.body!], httpEvent.headers.get('File-Name')!, { type: `${httpEvent.headers.get('Content-Type')};charset=utf-8` })); } this.fileStatus.status = 'done'; break; default: console.log(httpEvent); break;
    }
  }

  private updateStatus(
    loaded: number,
    total: number,
    requestType: string
  ): void {
    this.fileStatus.status = 'progress';
    this.fileStatus.requestType = requestType;
    this.fileStatus.percent = Math.round((100 * loaded) / total);
  }
}
