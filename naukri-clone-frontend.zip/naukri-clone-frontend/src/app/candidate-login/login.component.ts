import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { ServicesService } from '../services.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private router: Router, private authService: AuthService, private getData: ServicesService) { }

  // userArray={email: 'b@gmail.com', password: 'bs', role : 'recruiter'};

  singleUser = { email: '', password: '', role: '' };


  onSubmit(form) {

    if (this.singleUser.role === "candidate") {
      this.getData.checkLoginForCandidate(this.singleUser).
        subscribe((response: any) => {
          debugger;
          console.log(response);
          if(response !== null){
            this.router.navigate(['/candidate']);
            localStorage.setItem("candidateloginid", JSON.stringify(response));
          }
          else{
            alert('User doesnt exists');
          }

        });
    }
    if (this.singleUser.role === "recruiter") {
      this.getData.checkLoginForRecruiter(this.singleUser).
        subscribe((response: any) => {
          console.log(response);
          if(response !== null){
            this.router.navigate(['/recruiter']);
            localStorage.setItem("recruiterloginid", JSON.stringify(response.recruiterId));
            localStorage.setItem("companyname", JSON.stringify(response.company));
          }
          else{
            alert('User doesnt exists');
          }

        });
    }
    // if (this.singleUser.role === "admin") {
    //   this.getData.checkLoginForAdmin(this.singleUser).
    //     subscribe((response: any) => {
    //       console.log(response);
    //       if(response !== null){
    //         this.router.navigate(['/admin']);
    //         localStorage.setItem("adminloginid", JSON.stringify(response));
    //       }
    //       else{
    //         alert('User doesnt exists');
    //       }

    //     });
    // }

    form.reset();
  }

}