import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ServicesService {
  constructor(private http: HttpClient) {}

  url: string = 'http://172.16.29.143:8080';
  // url:string= 'http://localhost:8080';
  checkLoginForCandidate(data: any) {
    return this.http.post(`${this.url}/auth/candidateLogin`, data);
  }
  checkLoginForRecruiter(data: any) {
    return this.http.post(`${this.url}/auth/recruiterLogin`, data);
  }
  checkLoginForAdmin(data: any) {
    return this.http.post(`${this.url}/auth/adminLogin`, data);
  }
  recruiterRegister(data: any) {
    return this.http.post(`${this.url}/recruiter/signup`, data);
  }
  candidateRegister(data: any) {
    return this.http.post(`${this.url}/candidate/signup`, data);
  }

  upload(formData: FormData): Observable<HttpEvent<string[]>> {
    return this.http.post<string[]>(`${this.url}/file/upload`, formData, 
    {
      reportProgress: true,
      observe: 'events',
    });
  }
}
