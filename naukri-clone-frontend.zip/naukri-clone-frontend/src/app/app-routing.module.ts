import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorPageComponent } from './error-page/error-page.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './candidate-login/login.component';
import { RecruiterComponent } from './recruiterregister/recruiter.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [
  {path : '', component : HomepageComponent},
  {path : 'login', component : LoginComponent},
  {path : 'register', component : RegisterComponent},
  {path : 'recruiterregister', component : RecruiterComponent},


  {path: 'candidate', loadChildren: () => import('./modules/candidate/candidate.module').then(m => m.CandidateModule)},
  {path: 'recruiter', loadChildren: () => import('./modules/recruiter/recruiter.module').then(m => m.RecruiterModule)},
  {path: 'admin', loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule)},
  
  { path: 'not-found', component: ErrorPageComponent, data: {message: 'Page not found!'} },
  { path: '**', redirectTo: '/not-found' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
