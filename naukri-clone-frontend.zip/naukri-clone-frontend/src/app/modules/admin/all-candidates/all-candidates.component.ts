import { Component } from '@angular/core';
import { AdminservicesService } from '../adminservices.service';

@Component({
  selector: 'app-all-candidates',
  templateUrl: './all-candidates.component.html',
  styleUrls: ['./all-candidates.component.css']
})
export class AllCandidatesComponent {

  candidates : any;
  constructor(private getData : AdminservicesService){
    this.getData.getAllCandidates().
    subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.candidates=data;
    })
  }
}
