import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class AdminservicesService {

  url: string = 'http://172.16.29.143:8080';
  // url:string= 'http://localhost:8080';
  constructor(private http : HttpClient) { }

  getAllJobs()
  {
    return this.http.get(`${this.url}/job/jobs`);
  }
  postJobDetails(data:any){
    return this.http.post(`${this.url}/job/postJob`,data);
  }

  getAllCandidates(){
    return this.http.get(`${this.url}/admin/viewAllCandidates`)
  }

  searchByDesignation(text:string,companyName:string, location:string){
    let params:any = {};
    params.designation = text
      params.company = companyName
      params.location = location
    return this.http.get(`${this.url}/job/filterJobs`,{params:params});
  }
}