import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { FormsModule } from '@angular/forms';
import { AdminRoutingModule } from './admin-routing.module';
import { ViewjobsComponent } from './viewjobs/viewjobs.component';
import { HttpClientModule } from '@angular/common/http';
import { AllCandidatesComponent } from './all-candidates/all-candidates.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import {NgxPaginationModule} from 'ngx-pagination';
@NgModule({
  declarations: [
    AdminComponent,
    AdminhomepageComponent,
    ViewjobsComponent,
    AllCandidatesComponent,
    MyProfileComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AdminRoutingModule,
    HttpClientModule,
    NgxPaginationModule
  ]
})
export class AdminModule { }
