import { Component } from '@angular/core';
import { AdminservicesService } from '../adminservices.service';
import { Router} from '@angular/router'

@Component({
  selector: 'app-viewjobs',
  templateUrl: './viewjobs.component.html',
  styleUrls: ['./viewjobs.component.css']
})
export class ViewjobsComponent {

  users : any;
  searchText : string = '';
  searchCompany : string = '';
  searchLocation : string= '';
  p=1;
  constructor(private getData : AdminservicesService, private router : Router){

    getData.getAllJobs()
    .subscribe((data:any) => {
      console.log(data);
      this.users=data;
    });
  }

  applyJob(){
    this.router.navigate(['/candidate']);
  }

  search(){
    this.getData.searchByDesignation(this.searchText,this.searchCompany, this.searchLocation).
    subscribe((data:any)=>{
      console.log(data);
      this.users=data;
    })
  }

  reset(){
    this.getData.getAllJobs()
    .subscribe((data:any) => {
      console.log(data);
      this.users=data;
      this.searchText='';
      this.searchCompany='';
      this.searchLocation='';
    });
  }
  
}
