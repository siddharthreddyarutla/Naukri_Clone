import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { AllCandidatesComponent } from './all-candidates/all-candidates.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ViewjobsComponent } from './viewjobs/viewjobs.component';


const routes : Routes =[
    { path : '', children : [
        { path : '', component : AdminhomepageComponent}, 
        { path : 'viewjobs', component : ViewjobsComponent},
        { path : 'allcandidates', component : AllCandidatesComponent},
        { path : 'myprofile', component : MyProfileComponent}
    ]}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule] 
  })
  export class AdminRoutingModule { }