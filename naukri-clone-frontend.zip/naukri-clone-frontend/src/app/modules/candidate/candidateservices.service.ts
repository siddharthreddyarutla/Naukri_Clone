import { Injectable } from '@angular/core';
import { HttpClient , HttpParams} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CandidateServicesService {



  constructor(private http: HttpClient ) { }

  url:string = "http://172.16.29.143:8080";
  // url:string= 'http://localhost:8080';
  getPrimaryJobDetails() {
    return this.http.get(`${this.url}/job/primaryJobDto`);
  }

  getCompleteJobDetails(id: number) {
    return this.http.get(`${this.url}/job/completeJobDto/` + id);
  }

  postCandidateExperience(data: any, id: number) {
    return this.http.post(`${this.url}/candidate/experience?candidateId=` + id, data);
  }

  postCandiateSkills(data: any, id: number) {
    return this.http.post(`${this.url}/candidate/skill?candidateId=` + id, data);
  }

  postCandidateQualifications(data: any, id: number) {
    return this.http.post(`${this.url}/candidate/qualifications?candidateId=` + id, data);
    debugger;
  }

  applyJob(data: any) {
    return this.http.post(`${this.url}/job/apply`, data);
  }
  viewAppliedJobs(id: number) {
    return this.http.get(`${this.url}/job/appliedJobs?candidateId=` + id);
  }

  getCandidateProfile(id: number) {
    return this.http.get(`${this.url}/candidate/get?candidateId=` + id);
  }

  getCompanyDetails(name: string) {
    return this.http.get(`${this.url}/job/companyDetails?companyName=` + name);
  }

  
  getCompanyAndLocationOnSearch(designation:string,companyName:string, location:string){
    let params:any = {};
    if(designation.trim().length > 0){
      params.designation = designation
      params.company = companyName.trim().length > 0 ? companyName : ''
      params.location = location.trim().length > 0 ? location : ''
    }
    if(companyName.trim().length > 0)
    {
      params.designation = designation.trim().length > 0 ? designation : ''
      params.company = companyName
      params.location = location.trim().length > 0 ? location : ''
    }
    if(location.trim().length > 0){
      params.designation = designation.trim().length > 0 ? designation : ''
      params.company = companyName.trim().length > 0 ? companyName : ''
      params.location = location
    }
    return this.http.get(`${this.url}/job/filterJobs`,{params:params});
  }
}
