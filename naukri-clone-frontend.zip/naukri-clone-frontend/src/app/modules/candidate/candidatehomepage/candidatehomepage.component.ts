import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { CandidateServicesService } from '../candidateservices.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { User } from '../../recruiter/user';


@Component({
  selector: 'app-candidatehomepage',
  templateUrl: './candidatehomepage.component.html',
  styleUrls: ['./candidatehomepage.component.css']
})
export class CandidatehomepageComponent {


  page = 1;
  Id: number = JSON.parse(localStorage.getItem("candidateloginid"));
  searchText: string = '';
  searchCompany: string = '';
  searchLocation: string = '';
  users: any[];
  job_id: number;
  response_body: any = {};
  all_users: any = {};

  constructor(private router: Router, private authService: AuthService, private userData: CandidateServicesService, private modalService: NgbModal) {

    userData.getPrimaryJobDetails().subscribe((data: any) => {
      debugger;
      console.log(data);
      this.users = data;
    });
  }

  userLogout() {
    this.authService.logout();
    localStorage.removeItem("candidateloginid");
    this.router.navigate(['/']);
  }

  oneUser(user: any) {
    debugger;
    this.router.navigate(['/candidate/viewjobs/' + user.jobId]);
  }

  // @Output()
  // search : EventEmitter<string> = new EventEmitter<string>();

  // onSearch(){
  //   this.search.emit(this.search_text);
  // }


  // response_body = {
  //   candidateId: this.Id,
  //   status: 'pending'
  // }

  openJobDetails(targetModal, user) {
    debugger;
    // this._route.params.subscribe((param: any) => {
    this.userData.getCompleteJobDetails(user.jobId).subscribe((data: any) => {
      debugger;
      console.log(data);
      this.all_users = data;
    });
    // })
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg',
    });


  }
  company_details:any;
   openCompanyDetails(targetModal,user){

    this.userData.getCompanyDetails(user.company).
    subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.company_details = data;
    })

    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg',
    });
   }

  

  apply(user: any) {
    if (this.job_id !== user.jobId) {
      this.response_body = {
        candidateId: this.Id,
        jobId: user.jobId,
        status: 'Pending'
      }
      this.userData.applyJob(this.response_body).
        subscribe(data => {
          debugger;
          console.log(data);
          alert('Job applied successfully');
          this.job_id = user.jobId;
        })
    }
    else{
      alert('You have already applied for this job!');
    }
  }
  
  search(){
    this.userData.getCompanyAndLocationOnSearch(this.searchText,this.searchCompany,this.searchLocation).
    subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.users=data;
    })
  }

  reset(){
    this.userData.getPrimaryJobDetails().subscribe((data: any) => {
      debugger;
      console.log(data);
      this.users = data;
      this.searchText='';
      this.searchCompany='';
      this.searchLocation='';
    });
  }


}
