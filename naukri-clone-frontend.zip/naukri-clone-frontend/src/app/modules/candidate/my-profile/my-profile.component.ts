import { Component } from '@angular/core';
import { CandidateServicesService } from '../candidateservices.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent {

  
  candidate:any;
  Id:number=JSON.parse(localStorage.getItem("candidateloginid"));
  constructor(private getData : CandidateServicesService) {
    debugger;
    this.getData.getCandidateProfile(this.Id)
    .subscribe((data:any)=>{
      console.log(data);
      this.candidate=data;
    })
  }
}
