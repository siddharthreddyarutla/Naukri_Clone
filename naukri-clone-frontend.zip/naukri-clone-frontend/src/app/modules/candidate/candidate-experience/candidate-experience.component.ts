import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'
import { CandidateServicesService } from '../candidateservices.service';
@Component({
  selector: 'app-candidate-experience',
  templateUrl: './candidate-experience.component.html',
  styleUrls: ['./candidate-experience.component.css']
})
export class CandidateExperienceComponent {



  constructor(private router: Router, private getData: CandidateServicesService) {
  }

  ngOnInit() {

  }
  Id: number = JSON.parse(localStorage.getItem("candidateloginid"));

  public experiences: any[] = [{
    id: 1,
    candidateId: this.Id,
    companyName: '',
    designation: '',
    experience: ''
  }];

  candidateExperience:any[]=[];
  candidate_experience:any={
    companyName:'',
    designation: '',
    experience: ''
  };

  addExperience() {
    console.log(this.candidate_experience);
    this.candidateExperience.push(this.candidate_experience);
    this.candidate_experience={};
    console.log(this.candidateExperience);
  }

 
  removeExperience(i: number) {
    this.candidateExperience.splice(i, 1);
  }

  logValue() {
    //console.log(this.experiences);
    this.getData.postCandidateExperience(this.candidateExperience, this.Id)
      .subscribe((response) => {
        console.log(response);
        this.candidateExperience=[];
        alert('Data Saved Successfully');
      });
  }
  back() {
    this.router.navigate(['/candidate']);
  }
}
