import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { CandidateExperienceComponent } from './candidate-experience/candidate-experience.component';
import { CandidateSkillsComponent } from './candidate-skills/candidate-skills.component';
import { CandidateComponent } from './candidate.component';
import { CandidatehomepageComponent } from './candidatehomepage/candidatehomepage.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyapplicationsComponent } from './myapplications/myapplications.component';
import { MydetailsComponent } from './mydetails/mydetails.component';

const routes: Routes = [
    {path : '', children:[
        {path : '', component : CandidatehomepageComponent},
        {path : 'mydetails', component : MydetailsComponent },
        {path : 'myapplications', component : MyapplicationsComponent },
        {path : 'myprofile', component : MyProfileComponent },
        {path : 'candidateexperience', component :CandidateExperienceComponent},
        {path : 'candidateskills', component: CandidateSkillsComponent},
      
    ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule] 
})
export class CandidateRoutingModule { }
