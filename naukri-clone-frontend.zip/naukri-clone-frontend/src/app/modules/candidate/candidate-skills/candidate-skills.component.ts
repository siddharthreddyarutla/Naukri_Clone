import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'
import { CandidateServicesService } from '../candidateservices.service';
@Component({
  selector: 'app-candidate-skills',
  templateUrl: './candidate-skills.component.html',
  styleUrls: ['./candidate-skills.component.css']
})
export class CandidateSkillsComponent {

  constructor(private router: Router, private getData: CandidateServicesService) {

  }

  Id: number = JSON.parse(localStorage.getItem("candidateloginid"))
  public skills: any[] = [{
    id: 1,
    candidateId: this.Id,
    skill: ''

  }];
  ngOnInit() {

  }

  candidateSkills : any[]=[];
  candidate_skill:string='';
  addSkill() {
    console.log(this.candidate_skill);
    this.candidateSkills.push(this.candidate_skill);
    this.candidate_skill='';
    console.log(this.candidateSkills);

  }

  removeSkill(i: number) {
    this.candidateSkills.splice(i, 1);
  }

  logValue() {
    //console.log(this.skills);
    this.getData.postCandiateSkills(this.candidateSkills, this.Id)
      .subscribe((response) => {
        console.log(response);
        this.candidateSkills=[];
        alert('Data Saved Successfully');
      });
  }

  back() {
    this.router.navigate(['/candidate']);
  }
}
