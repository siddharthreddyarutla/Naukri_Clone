import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'
import { CandidateServicesService } from '../candidateservices.service';
@Component({
  selector: 'app-mydetails',
  templateUrl: './mydetails.component.html',
  styleUrls: ['./mydetails.component.css']
})
export class MydetailsComponent {


  constructor(private router: Router, private getData: CandidateServicesService) {


    //console.log(this.Id);
  }

  Id: number = JSON.parse(localStorage.getItem("candidateloginid"));
  public qualifications: any[] = [{
    id: 1,
    candidateId: this.Id,
    educationType: '',
    institute: '',
    percentage: ''

  }];

  ngOnInit() {

  }

  candidateQualifications:any[]=[];
  
  candidate_qualification:any={
    educationType:'',
    institute:'',
    percentage:''
  };


  addQualification() {
    console.log(this.candidate_qualification);
    this.candidateQualifications.push(this.candidate_qualification);
    this.candidate_qualification={};
    console.log(this.candidateQualifications);
  }

  removeQualification(i: number) {
    this.candidateQualifications.splice(i, 1);
  }

  logValue() {
    //console.log(this.qualifications);

    debugger;
    this.getData.postCandidateQualifications(this.candidateQualifications,this.Id)
      .subscribe((response) => {
        // debugger; 
        console.log(response);
        this.candidateQualifications=[];
        alert('Data saved successfully')
      });
  }


}
