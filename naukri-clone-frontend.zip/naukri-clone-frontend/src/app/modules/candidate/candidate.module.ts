import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CandidateComponent } from './candidate.component';
import { CandidateRoutingModule } from './candidate-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { MydetailsComponent } from './mydetails/mydetails.component';
import { MyapplicationsComponent } from './myapplications/myapplications.component';
import { FormsModule } from '@angular/forms';
import { CandidateExperienceComponent } from './candidate-experience/candidate-experience.component';
import { CandidateSkillsComponent } from './candidate-skills/candidate-skills.component';
import { CandidatehomepageComponent } from './candidatehomepage/candidatehomepage.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
//import { FilterPipe } from './pipes/filter.pipe';
import { CandidateServicesService } from './candidateservices.service';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    CandidateComponent,
    CandidatehomepageComponent,
    MydetailsComponent,
    MyapplicationsComponent,
    CandidateExperienceComponent,
    CandidateSkillsComponent,
    MyProfileComponent,
  //  FilterPipe
  ],
  imports: [
    CommonModule,
    CandidateRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
    
  ]
})
export class CandidateModule { }
