import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateServicesService } from '../candidateservices.service';

@Component({
  selector: 'app-myapplications',
  templateUrl: './myapplications.component.html',
  styleUrls: ['./myapplications.component.css']
})
export class MyapplicationsComponent {

  candidates: any[];
  Id:number=JSON.parse(localStorage.getItem("candidateloginid"));
  constructor(private router : Router,getData : CandidateServicesService){
    getData.viewAppliedJobs(this.Id).subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.candidates=data;
    })
  }
 


}
