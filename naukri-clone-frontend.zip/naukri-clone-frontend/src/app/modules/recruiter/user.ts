export class User{
    constructor(
        public designation : string,
        public doj:Date,
        public posting_date : Date,
        public vacancy: number,
        public applicants: number,
        public location :string,
        public description : string,
        public expiryDate : Date,
        public minExperience : number,
        public maxExperience : number,
        public skill : any,
        public qualification : any
    ){

    }
}
