import { Component } from '@angular/core';
import { RecruiterServicesService } from '../recruiterservices.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent {

  recruiter:any;
  Id:number=JSON.parse(localStorage.getItem("recruiterloginid"));
  constructor(private getData : RecruiterServicesService){
    this.getData.getRecruiterProfile(this.Id).
    subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.recruiter=data;
    })
  }

}
