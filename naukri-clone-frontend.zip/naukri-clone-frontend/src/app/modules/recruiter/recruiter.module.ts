import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecruiterComponent } from './recruiter.component';
import { RecruiterRoutingModule } from './recruiter-routing.module';
import { RecruiterhomepageComponent } from './recruiterhomepage/recruiterhomepage.component';
import { PostjobComponent } from './postjobDetails/postjob.component';
import { FormsModule } from '@angular/forms';
import { RequiredSkillsComponent } from './required-skills/required-skills.component';
import { RequiredQualificationsComponent } from './required-qualifications/required-qualifications.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewApplicantsComponent } from './view-applicants/view-applicants.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { AddcourseComponent } from './addcourse/addcourse.component';
@NgModule({
  declarations: [
    RecruiterComponent,
    RecruiterhomepageComponent,
    PostjobComponent,
    RequiredSkillsComponent,
    RequiredQualificationsComponent,
    CompanyDetailsComponent,
    ViewApplicantsComponent,
    MyProfileComponent,
    AddcourseComponent
  ],
  imports: [
    CommonModule,
    RecruiterRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ]
})
export class RecruiterModule { }
