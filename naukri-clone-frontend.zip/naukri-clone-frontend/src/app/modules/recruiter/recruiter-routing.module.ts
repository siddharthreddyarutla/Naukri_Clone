import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { AddcourseComponent } from './addcourse/addcourse.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { PostjobComponent } from './postjobDetails/postjob.component';
import { RecruiterhomepageComponent } from './recruiterhomepage/recruiterhomepage.component';
import { RequiredQualificationsComponent } from './required-qualifications/required-qualifications.component';
import { RequiredSkillsComponent } from './required-skills/required-skills.component';
import { ViewApplicantsComponent } from './view-applicants/view-applicants.component';
import { ViewJobsComponent } from './view-jobs/view-jobs.component';

const routes: Routes = [
    { path : '' , children : [
        { path : '' , component : RecruiterhomepageComponent},
        { path : 'postjobdetails' , component : PostjobComponent},
        { path : 'companydetails', component : CompanyDetailsComponent},
        { path : 'requiredqualifications', component : RequiredQualificationsComponent},
        { path : 'requiredskills', component : RequiredSkillsComponent},
        { path : 'viewjobs/:jobId', component : ViewJobsComponent},
        { path : 'viewapplicants/:jobId', component : ViewApplicantsComponent},
        { path : 'myprofile', component : MyProfileComponent},
        { path : 'addcourse', component : AddcourseComponent}
    ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecruiterRoutingModule { }