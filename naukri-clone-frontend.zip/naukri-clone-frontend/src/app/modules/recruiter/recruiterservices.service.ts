import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class RecruiterServicesService {
  constructor(private http: HttpClient) {}

  url: string = 'http://172.16.29.143:8080';
  // url:string= 'http://localhost:8080';
  getRecruiterPrimaryJobs(id: number) {
    return this.http.get(
      `${this.url}/recruiter/getJobsPostedByMe?recruiterId=` + id
    );
  }

  getMyCompleteJobDetails(id: number) {
    return this.http.get(`${this.url}/job/completeJobDto/` + id);
  }

  postCompanyDetails(data: any) {
    return this.http.post(`${this.url}/recruiter/company`, data);
  }

  postJobDetails(data: any) {
    return this.http.post(`${this.url}/job/postJob`, data);
  }

  postRequiredQualifications(data: any, id: number) {
    return this.http.post(`${this.url}/job/jobQualification?jobId=` + id, data);
  }

  postRequiredSkills(data: any, id: number) {
    return this.http.post(`${this.url}/job/jobSkills?jobId=` + id, data);
  }

  getPrimaryApplicants(id: number) {
    return this.http.get(`${this.url}/recruiter/primaryCandidateDto/` + id);
  }

  applicationAccept(data: any) {
    return this.http.put(`${this.url}/recruiter/changeJobStatus`, data);
  }

  applicationReject(data: any) {
    return this.http.put(`${this.url}/recruiter/changeJobStatus`, data);
  }

  getRecruiterProfile(id: number) {
    return this.http.get(`${this.url}/recruiter/get?recruiterId=` + id);
  }
  getSearchJobs(data: string, id : number) {
    let params:any = {};
    params.designation = data
    params.recruiterId = id
    return this.http.get(`${this.url}/job/searchJobs`,{params:params});
  }

  getCompleteCandidateDetails(id: number) {
    return this.http.get(
      `${this.url}/candidate/getCompleteCandidate?candidateId=` + id
    );
  }

  closeJobs(id: number) {
    return this.http.delete(`${this.url}/recruiter/deleteJob?jobId=` + id);
  }

  download(filename: string): Observable<HttpEvent<Blob>> {
    return this.http.get(`${this.url}/file/download/${filename}/`, {
      reportProgress: true,
      observe: 'events',
      responseType: 'blob',
    });
  }

  searchCandidateByNoticePeriod(data:any){
    return this.http.get(`${this.url}/recruiter/searchCandidate?noticePeriod=`+data)
  }

  searchCourses(data:any){
    return this.http.post(`${this.url}/course/searchCourses`,data);
  }
}