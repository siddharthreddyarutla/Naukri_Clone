import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RecruiterServicesService } from '../recruiterservices.service';
@Component({
  selector: 'app-required-qualifications',
  templateUrl: './required-qualifications.component.html',
  styleUrls: ['./required-qualifications.component.css']
})
export class RequiredQualificationsComponent {

  constructor(private getData: RecruiterServicesService) { }

  Id:number=JSON.parse(localStorage.getItem("jobid"));
  allQualifications :any[]=[];



  public qualifications: any[] = [{
   id: 1, 
    jobId: this.Id
  }];

  // required_qualification= new Array();

  requiredQualification:any[]=[];
  all_qualification:any={
    qualification:'',
    percentage:''
  }
  
  ngOnInit() {
    
  }
  
 
  addQualification() {
    console.log(this.all_qualification);
    this.requiredQualification.push(this.all_qualification);
    this.all_qualification={};
    console.log(this.requiredQualification)

  }


  removeQualification(i: number) {
    this.requiredQualification.splice(i, 1);

  }

  logValue() {
    // console.log(this.qualifications);
    // requetstBody{
    //   jobId=this.Id,
    //   qu
    // }
    this.getData.postRequiredQualifications(this.requiredQualification,this.Id)
      .subscribe((response) => {
        debugger;
        console.log(response);
        alert('Data Submitted Successfully');
        this.requiredQualification=[];
      });
    
  }
}
