import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RecruiterServicesService } from '../recruiterservices.service';
@Component({
  selector: 'app-postjob',
  templateUrl: './postjob.component.html',
  styleUrls: ['./postjob.component.css']
})
export class PostjobComponent {


  constructor(private router: Router, private getData: RecruiterServicesService) {


  }

  Id: number = JSON.parse(localStorage.getItem("recruiterloginid"));
  company:string = JSON.parse(localStorage.getItem("companyname"));
  jobpost_details = {
    recruiterId: this.Id,
    designation: '',
    doj: '',
    posting_date: '',
    vacancy: '',
    // applicants: '',
    location: '',
    description: '',
    expiryDate: '',
    minExperience: '',
    maxExperience: '',
    ctc: '',
    company: this.company
  }


  JobPost(data: any) {
    // console.log(data);
    this.getData.postJobDetails(this.jobpost_details)
      .subscribe((response) => {
        console.log(response);
        alert('Job posted successfully');
        localStorage.setItem("jobid",JSON.stringify(response));
        
      });
    // this.router.navigate(['/recruiter/companydetails']);
  }

  back() {
    this.router.navigate(['/recruiter/companydetails']);
  }

  // title = 'project_part6';
  // name = 'Dynamic Add Fields';
  // values: any = [];
  // ngOnInit() {}

  // removevalue(i: number) {
  //   this.values.splice(i, 1);
  // }

  // addvalue() {
  //   this.values.push({ value: '' });
  // }
}
