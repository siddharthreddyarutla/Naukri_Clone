import { Component } from '@angular/core';
import { RecruiterServicesService } from '../recruiterservices.service';

@Component({
  selector: 'app-required-skills',
  templateUrl: './required-skills.component.html',
  styleUrls: ['./required-skills.component.css']
})
export class RequiredSkillsComponent {

  Id:number=JSON.parse(localStorage.getItem("jobid"));
  public skills: any[] = [{
    id: 1,
    jobId:this.Id,
    skill: ''

  }];

  ngOnInit() {

  }

  constructor(private getdata: RecruiterServicesService) {

  }

  requiredSkills : any[]=[];
  required_skill:string='';

  addSkill() {
    console.log(this.required_skill);
    this.requiredSkills.push(this.required_skill);
    this.required_skill='';
    console.log(this.requiredSkills);
  }

  removeSkill(i: number) {
    this.requiredSkills.splice(i, 1);
  }

  logValue() {
    //console.log(this.skills);
    this.getdata.postRequiredSkills(this.requiredSkills,this.Id).
      subscribe((response) => {
        console.log(response);
        alert('Data Submitted Successfully');
        this.requiredSkills=[];
      })
  }
  postAllJobs(){
    alert('All Details posted successfully');
    localStorage.removeItem("jobid");
  }

}
