import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { RecruiterServicesService } from '../recruiterservices.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { User } from '../user';

import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-recruiterhomepage',
  templateUrl: './recruiterhomepage.component.html',
  styleUrls: ['./recruiterhomepage.component.css']
})
export class RecruiterhomepageComponent {

  p= 1;
  Id:number=JSON.parse(localStorage.getItem("recruiterloginid"));
  original_users:any;
  users: any;
  all_users:any;
  searchText :string ='';
  
  constructor(private router: Router, private authService: AuthService, private getData: RecruiterServicesService, private modalService : NgbModal, private _route: ActivatedRoute) {

    getData.getRecruiterPrimaryJobs(this.Id).subscribe((data: any) => {
      debugger;
      console.log(data);
      this.users = data;
      // this.original_users=data;
    });

    // this._route.params.subscribe((param: any) => {
    //   getData.getMyCompleteJobDetails(param['jobId']).subscribe((data: any) => {
    //     // debugger;
    //     console.log(data);
    //     this.all_users = data;
    //   });
    // })
  }

  getPrimaryApplicantsList(){
    this.getData.getRecruiterPrimaryJobs(this.Id)
    .subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.users=data;
    })
  }
  userLogout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  oneUserDetails(user: any) {
    debugger;
    this.router.navigate(['/recruiter/viewjobs/' + user.jobId]);
  }

  

  // User:any[]=[];
  openDetails(targetModal, user) {
    debugger;
    // this._route.params.subscribe((param: any) => {
      this.getData.getMyCompleteJobDetails(user.jobId).subscribe((data: any) => {
        debugger;
        console.log(data);
        this.all_users = data;
      });
    // })
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg',
    });
    
  
  }

  logout() {
    localStorage.removeItem("recruiterloginid");
    localStorage.removeItem("companyname");
    this.router.navigate(['/']);
  }


  viewApplicants(user:any){
    this.router.navigate(['/recruiter/viewapplicants/'+ user.jobId]);
  }

  // if (!users) return [];
  //   if (!searchText) return users;
  // search(){
  //   if(!this.searchText){
  //     this.users=this.original_users
  //   }
  //   else{
  //     this.getData.getSearchJobs(this.searchText).
  //     subscribe((data:any)=>{
  //       console.log(data);
  //       this.users=data;
  //     })
  //   }
   
  // }
  // reset(){
  //   this.searchText='';
  //   this.search();
  // }

  search(){
    this.getData.getSearchJobs(this.searchText,this.Id).
      subscribe((data:any)=>{
        console.log(data);
        this.users=data;
        this.reset();
      })
  }

  reset(){
    if(this.searchText=='')
    {
      this.getData.getRecruiterPrimaryJobs(this.Id).subscribe((data: any) => {
        console.log(data);
        this.users = data;
      });
    }
    // this.getData.getRecruiterPrimaryJobs(this.Id).subscribe((data: any) => {
    //     // debugger;
    //     // this.searchText='';
    //     console.log(data);
    //     this.users = data;
    //     // this.original_users=data;
    //   });
  }
  closeJob(data:any){
    this.getData.closeJobs(data.jobId).
    subscribe((response)=>{
      console.log(response);
      this.getPrimaryApplicantsList();
    })
  }
}
