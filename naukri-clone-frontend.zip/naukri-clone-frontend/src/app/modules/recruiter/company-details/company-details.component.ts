import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { RecruiterServicesService } from '../recruiterservices.service';
@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.css']
})
export class CompanyDetailsComponent {

  constructor(private router: Router, private getData: RecruiterServicesService) {
    console.log(this.Id);
   }



  Id: number = JSON.parse(localStorage.getItem("recruiterloginid"));
  company:string = JSON.parse(localStorage.getItem("companyname"));
  company_register = {
    recruiterId: this.Id,
    names: this.company,
    about: '',
    strength: ''
  };
  
  saveCompanyDetails(data: any) {
    // console.log(data);
    this.getData.postCompanyDetails(this.company_register)
      .subscribe((response) => {
        console.log(response);
        alert('Data Submitted Successfully');
      });
      
  }

}
