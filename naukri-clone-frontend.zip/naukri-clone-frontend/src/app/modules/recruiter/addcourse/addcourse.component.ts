import { Component } from '@angular/core';
import { RecruiterServicesService } from '../recruiterservices.service';

@Component({
  selector: 'app-addcourse',
  templateUrl: './addcourse.component.html',
  styleUrls: ['./addcourse.component.css']
})
export class AddcourseComponent {

  AllCourseDetails : any ={
    courseName : '',
    recruiterEmail  : '',
    skills:[]=[]
  }

  courses:any;

  multipleSkills:any={
    skill:''
  }
  addSkill() {
    console.log(this.multipleSkills);
    this.AllCourseDetails.skills.push(this.multipleSkills);
    this.multipleSkills={};
    console.log(this.AllCourseDetails.skills);
    console.log(this.AllCourseDetails);
  }
  removeSkill(i: number) {
    this.AllCourseDetails.skills.splice(i, 1);

  }


  constructor(private getData : RecruiterServicesService){}

  search(){
    this.getData.searchCourses(this.AllCourseDetails).
    subscribe((response:any)=>{
      debugger;
      console.log(response);
      this.courses=response;
    })
  }

  reset(){
    this.AllCourseDetails={};
  }
}
