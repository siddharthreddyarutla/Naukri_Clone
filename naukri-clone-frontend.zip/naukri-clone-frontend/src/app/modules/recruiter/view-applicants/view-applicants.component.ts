import { Component } from '@angular/core';
import { RecruiterServicesService } from '../recruiterservices.service';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CandidateComponent } from '../../candidate/candidate.component';
import { HttpErrorResponse, HttpEvent, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-view-applicants',
  templateUrl: './view-applicants.component.html',
  styleUrls: ['./view-applicants.component.css'],
})
export class ViewApplicantsComponent {
  applicants: any;
  job_id: any;
  candidate: any;
  filenames: string[] = [];
  fileStatus = { status: '', requestType: '', percent: 0 };
  searchText : number;
  constructor(
    private getData: RecruiterServicesService,
    private _route: ActivatedRoute,
    private modalService: NgbModal
  ) {
    this._route.params.subscribe((param: any) => {
      this.job_id = param['jobId'];
      this.getData.getPrimaryApplicants(this.job_id).subscribe((data: any) => {
        debugger;
        console.log(data);
        this.applicants = data;
      });
    });
  }

  response_body_toaccept: any;
  acceptApplicantion(data: any) {
    this.response_body_toaccept = {
      jobId: parseInt(this.job_id),
      candidateId: data.candidateId,
      status: 'Accepted',
    };
    this.getData
      .applicationAccept(this.response_body_toaccept)
      .subscribe((data: any) => {
        console.log(data);
        alert('Application accepted successfully');
      });
  }

  response_body_toreject: any;
  rejectApplication(data: any) {
    this.response_body_toreject = {
      jobId: parseInt(this.job_id),
      candidateId: data.candidateId,
      status: 'Rejected',
    };
    this.getData
      .applicationReject(this.response_body_toreject)
      .subscribe((data: any) => {
        console.log(data);
        alert('Application rejected successfully');
      });
  }

  openCandidateDetails(targetModal, data: any) {
    this.getData
      .getCompleteCandidateDetails(data.candidateId)
      .subscribe((response: any) => {
        debugger;
        console.log(response);
        this.candidate = response;
      });
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: 'static',
      size: 'lg',
    });
  }
  onDownloadFile(filename: string): void {
    this.getData.download(filename).subscribe(
      (event) => {
        console.log(event);
        this.resportProgress(event);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
      }
    );
  }

  private resportProgress(httpEvent: HttpEvent<string[] | Blob>): void {
    switch (httpEvent.type) {
      case HttpEventType.UploadProgress:
        this.updateStatus(httpEvent.loaded, httpEvent.total!, 'Uploading... ');
        break;
      case HttpEventType.DownloadProgress:
        this.updateStatus(
          httpEvent.loaded,
          httpEvent.total!,
          'Downloading... '
        );
        break;
      case HttpEventType.ResponseHeader:
        console.log('Header returned', httpEvent);
        break;
      default:
        console.log(httpEvent);
        break;
    }
  }
  private updateStatus(
    loaded: number,
    total: number,
    requestType: string
  ): void {
    this.fileStatus.status = 'progress';
    this.fileStatus.requestType = requestType;
    this.fileStatus.percent = Math.round((100 * loaded) / total);
  }

  search(){
    this.getData.searchCandidateByNoticePeriod(this.searchText).
    subscribe((data:any)=>{
      debugger;
      console.log(data);
      this.applicants=data;
    });
  }

  reset(){
    this.getData.getPrimaryApplicants(this.job_id).subscribe((data: any) => {
      debugger;
      console.log(data);
      this.applicants = data;
    });
  }
}
