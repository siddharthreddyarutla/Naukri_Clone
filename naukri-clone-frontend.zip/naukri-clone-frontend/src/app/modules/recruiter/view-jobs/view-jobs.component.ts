import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RecruiterServicesService } from '../recruiterservices.service';


@Component({
  selector: 'app-view-jobs',
  templateUrl: './view-jobs.component.html',
  styleUrls: ['./view-jobs.component.css']
})
export class ViewJobsComponent {

  users: any;

  constructor(private userData: RecruiterServicesService, private _route: ActivatedRoute) {
    this._route.params.subscribe((param: any) => {
      userData.getMyCompleteJobDetails(param['jobId']).subscribe((data: any) => {
        // debugger;
        console.log(data);
        this.users = data;
      });
    })


  }

}
