import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServicesService } from '../services.service';
@Component({
  selector: 'app-recruiter',
  templateUrl: './recruiter.component.html',
  styleUrls: ['./recruiter.component.css']
})
export class RecruiterComponent {


  constructor(private router: Router, private getData: ServicesService) { }
  recruiter_register = {
    names: '',
    phone: '',
    gender: '',
    company: '',
    designation: '',
    email: '',
    password: '',
    role: 'recruiter'

  }

  register(data: any) {
    this.getData.recruiterRegister(this.recruiter_register)
      .subscribe((response) => {
        console.log(response);
      });
    alert("Registered Successfully");
    this.router.navigate(['/login']);
  }

  back() {
    this.router.navigate(['/'])
  }


}
