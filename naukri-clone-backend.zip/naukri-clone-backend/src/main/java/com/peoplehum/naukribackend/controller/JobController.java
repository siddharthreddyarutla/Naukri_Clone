package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.candidate.CandidateApplicationDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateAppliedJobs;
import com.peoplehum.naukribackend.dto.candidate.SurveyDto;
import com.peoplehum.naukribackend.dto.job.*;
import com.peoplehum.naukribackend.serviceImplementation.CandidateServiceImplementation;
import com.peoplehum.naukribackend.serviceImplementation.JobServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/job")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class JobController {

    @Autowired
    CandidateServiceImplementation candidateServiceImplementation;
    @Autowired
    JobServiceImplementation jobServiceImplementation;

    @GetMapping("/jobs")
    public List<JobDto> getJobs(){
        return jobServiceImplementation.getJobs();
    }

    @PostMapping("/apply")
    public SurveyDto applyJob(@RequestBody CandidateApplicationDto candidateApplicationDto) throws IOException {
        SurveyDto surveyDto = candidateServiceImplementation.applyJob(candidateApplicationDto);
        return surveyDto;
    }

    @GetMapping("/appliedJobs")
    public List<CandidateAppliedJobs> appliedJobs(@RequestParam Long candidateId) {
        return candidateServiceImplementation.getJobsByCandidateId(candidateId);
    }

    @GetMapping("/searchJobs")
    public List<JobPrimaryDto> searchJob(@RequestParam String designation, @RequestParam Long recruiterId) {
        return jobServiceImplementation.searchJobs(designation, recruiterId);
    }

    @GetMapping("/filterJobs")
    public List<JobPrimaryDto> filterJob(@RequestParam(required = false) String designation, @RequestParam(required = false) String company, @RequestParam(required = false) String location) {
        System.out.println(designation + ' ' + company + ' ' + location);
        if(!location.isEmpty() && !company.isEmpty() && !designation.isEmpty()) {
            return jobServiceImplementation.filterJobByAll(designation, location, company);
        }
        else if(company.isEmpty() && designation.isEmpty()) {
            return jobServiceImplementation.filterJobByLocation(location);
        }
        else if (location.isEmpty() && designation.isEmpty()) {
            return jobServiceImplementation.filterJobByCompany(company);
        }
        else if(company.isEmpty() && location.isEmpty()) {
            return jobServiceImplementation.filterJobByDesignation(designation);
        }
        else if(company.isEmpty()) {
            return jobServiceImplementation.filterJobExcludingCompany(designation, location);
        }
        else if(location.isEmpty()) {
            return jobServiceImplementation.filterJobExcludingLocation(designation, company);
        }
        else {
            return jobServiceImplementation.filterJobExcludingDesignation(company, location);
        }
    }

    @GetMapping("/completeJobDto/{jobId}")
    public CompleteJobDto getCompleteJobDto(@PathVariable("jobId") Long jobId) {
        return jobServiceImplementation.getCompleteJobDto(jobId);
    }

    @GetMapping("/primaryJobDto")
    public List<JobPrimaryDto> getPrimaryJobDetails() {
        return jobServiceImplementation.getPrimaryJobDetails();
    }

    @GetMapping("/companyDetails")
    public CompanyDto getCompanyDetails(@RequestParam String companyName) {
        return candidateServiceImplementation.getCompanyDetails(companyName);
    }

    @PostMapping("/postJob")
    public Long addJob(@RequestBody JobDto jobDto) {

        return jobServiceImplementation.addJob(jobDto);
    }

    @PostMapping("/postJobDetails")
    public JobDetailsDto addJobDetails(@RequestBody JobDetailsDto jobDetailsDto) {
        return jobServiceImplementation.addJobDetails(jobDetailsDto);
    }

    @PostMapping("/jobSkills")
    public void addJobSkill(@RequestParam Long jobId, @RequestBody List<String> requiredSkills) {
        jobServiceImplementation.addSkill(jobId, requiredSkills);
    }

    @PostMapping("/jobQualification")
    public void addJobQualification(@RequestParam Long jobId, @RequestBody List<JobQualificationDto> requiredQualification) {
        jobServiceImplementation.addQualification(jobId, requiredQualification);
    }

    @PutMapping("/editJob")
    public boolean editJobDetails(@RequestParam Long recruiterId, @RequestParam Long jobId, @RequestParam int vacancy) {
        return jobServiceImplementation.editJob(recruiterId, jobId, vacancy);
    }
}
