package com.peoplehum.naukribackend.dto.job;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobPrimaryDto {
    private Long jobId;
    private String company;
    private String designation;
    private Date doj;
    private int vacancy;
    private long recruiterId;
    private String location;
    private int applicants;
    private Boolean visibility;
}
