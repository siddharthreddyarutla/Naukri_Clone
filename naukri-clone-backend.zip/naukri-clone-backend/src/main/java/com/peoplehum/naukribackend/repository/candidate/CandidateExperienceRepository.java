package com.peoplehum.naukribackend.repository.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateExperienceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateExperienceRepository extends JpaRepository<CandidateExperienceEntity, Long> {
    List<CandidateExperienceEntity> findByCandidateId(Long candidateId);
}
