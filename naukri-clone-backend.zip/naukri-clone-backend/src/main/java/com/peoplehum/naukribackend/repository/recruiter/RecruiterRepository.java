package com.peoplehum.naukribackend.repository.recruiter;

import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RecruiterRepository extends JpaRepository<RecruiterEntity, Long> {
    Optional<RecruiterEntity> findById(Long recruiterId);
}
