package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateExperienceEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateQualificationEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CompleteCandidateDto {
    private Long candidateId;
    private String name;
    private String gender;
    private String phone;
    private String email;
    private String password;
    private int noticePeriod;
    private String resume;
    private List<String> skill;
    private List<List<CandidateQualificationDto>> candidateQualifications;
    private List<List<CandidateExperienceDto>> candidateExperiences;
}