package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.candidate.*;
import com.peoplehum.naukribackend.dto.job.CompanyDto;
import com.peoplehum.naukribackend.dto.user.UserLoginDto;

import java.io.IOException;
import java.util.List;

public interface CandidateService {
    CandidateSignupDto addCandidate(CandidateSignupDto candidateSignupDto);

    void addQualification(Long candidateId, List<CandidateQualificationDto> listOfCandidateQualifications);

    void addExperience(Long candidateId, List<CandidateExperienceDto> listOfCandidateExperience);

    SurveyDto applyJob(CandidateApplicationDto candidateApplicationDto) throws IOException;

    List<CandidateAppliedJobs> getJobsByCandidateId(Long candidateId);

    CandidateDto updateCandidate(Long id, String name, String phone, String email, Integer noticePeriod, String resume, String password, String gender);

    void addSkills(Long candidateId, List<String> skill);

    CompleteCandidateDto getCandidate(Long candidateId);

    CompanyDto getCompanyDetails(String company);

    Long candidateLogin(UserLoginDto userLoginDto);

    CandidateQualificationDto getCandidateQualifications(Long candidateId);

    CandidateExperienceDto getCandidateExperience(Long candidateId);

    boolean deleteCandidateProfile(Long candidateId);

    CompleteCandidateDto getCompleteCandidate(Long candidateId);

    CandidateDetailsDto addCandidateDetails(CandidateDetailsDto candidateDetailsDto);
}
