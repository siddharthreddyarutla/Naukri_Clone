package com.peoplehum.naukribackend.serviceImplementation;

import com.peoplehum.naukribackend.dto.course.JobMappingDto;
import com.peoplehum.naukribackend.dto.course.NaukriCourseRequestDto;
import com.peoplehum.naukribackend.dto.course.NaukriCourseResponseDto;
import com.peoplehum.naukribackend.repository.course.JobMappingRepository;
import com.peoplehum.naukribackend.repository.course.NaukriCourseRepository;
import com.peoplehum.naukribackend.service.CourseraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;

@Service
public class CourseraServiceImplementation implements CourseraService {

    @Autowired
    NaukriCourseRepository naukriCourseRepository;
    @Autowired
    JobMappingRepository jobMappingRepository;

    @Override
    public List searchCourses(NaukriCourseRequestDto naukriCourseRequestDto) throws IOException {
        String url = "http://172.16.29.141:8091/course/job/search";
        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<List> response = restTemplate.postForEntity(url, naukriCourseRequestDto, List.class);

        List<Map<String, Object>> responseList = response.getBody();
//        System.out.println(responseList);
        List<NaukriCourseResponseDto> naukriCourses = new ArrayList<>();

        assert responseList != null;
        for (Map<String, Object> map : responseList) {
            NaukriCourseResponseDto naukriCourse = new NaukriCourseResponseDto();
            naukriCourse.setCourseId((Integer) map.get("courseId"));
            naukriCourse.setCourseName((String) map.get("courseName"));
            naukriCourse.setInstructorName((String) map.get("instructorName"));
            naukriCourses.add(naukriCourse);
            naukriCourseRepository.save(naukriCourse.toEntity());
        }
//        System.out.println(naukriCourses);
        return naukriCourses;
    }

    @Override
    public List<NaukriCourseResponseDto> selectedCoursesForAJob(Long jobId, List<NaukriCourseResponseDto> naukriCourseResponseDtoList) {
        for(NaukriCourseResponseDto ncr : naukriCourseResponseDtoList) {
            Long courseId = Long.valueOf(ncr.getCourseId());
            JobMappingDto jobMappingDto = new JobMappingDto(jobId, courseId, null);
            jobMappingRepository.save(jobMappingDto.toEntity());
        }
        return null;
    }
}
