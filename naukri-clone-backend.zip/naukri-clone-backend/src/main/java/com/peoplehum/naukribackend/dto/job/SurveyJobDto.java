package com.peoplehum.naukribackend.dto.job;

import com.peoplehum.naukribackend.dto.candidate.CandidateQualificationDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SurveyJobDto {
    private String jobDesignation;
    private String recruiterEmail;
    private Date doj;
    private Date posting_date;
    private int vacancy;
    private String location;
    private String description;
    private Date expiryDate;
    private int minExperience;
    private int maxExperience;
    private double ctc;
    private String surveyLink;
    private List<String> skill;
    private List<JobQualificationDto> qualification;
}
