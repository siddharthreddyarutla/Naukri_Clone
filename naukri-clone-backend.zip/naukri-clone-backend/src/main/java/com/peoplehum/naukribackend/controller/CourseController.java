package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.course.NaukriCourseResponseDto;
import com.peoplehum.naukribackend.dto.course.NaukriCourseRequestDto;
import com.peoplehum.naukribackend.serviceImplementation.CourseraServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/course")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CourseController {

    @Autowired
    CourseraServiceImplementation courseraServiceImplementation;

    @PostMapping("/searchCourses")
    public List<NaukriCourseResponseDto> searchCourses(@RequestBody NaukriCourseRequestDto naukriCourseRequestDto) throws IOException {
        return courseraServiceImplementation.searchCourses(naukriCourseRequestDto);
    }

    @PostMapping("/selectedCoursesForAJob")
    public List<NaukriCourseResponseDto> searchCourses(@RequestParam Long jobId, @RequestBody List<NaukriCourseResponseDto> naukriCourseResponseDtoList) {
        return courseraServiceImplementation.selectedCoursesForAJob(jobId, naukriCourseResponseDtoList);
    }
}
