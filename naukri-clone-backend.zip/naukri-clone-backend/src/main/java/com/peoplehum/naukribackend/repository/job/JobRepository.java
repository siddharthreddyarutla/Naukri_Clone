package com.peoplehum.naukribackend.repository.job;

import com.peoplehum.naukribackend.entity.job.JobEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<JobEntity, Long> {

    List<JobEntity> findByDesignation(String designation);

    List<JobEntity> findByLocation(String location);

    List<JobEntity> findAllByRecruiterId(Long recruiterId);

    List<JobEntity> findByCompany(String company);

    List<JobEntity> findByDesignationAndCompany(String designation, String company);

    List<JobEntity> findByDesignationAndCompanyAndLocation(String designation, String company, String location);

    List<JobEntity> findByDesignationAndLocation(String designation, String location);

    List<JobEntity> findByCompanyAndLocation(String company, String location);

    List<JobEntity> findByDesignationAndRecruiterId(String designation, Long recruiterId);

    List<JobEntity> findByExpiryDate(Date date);

    List<JobEntity> findAllByExpiryDate(Date date);
}