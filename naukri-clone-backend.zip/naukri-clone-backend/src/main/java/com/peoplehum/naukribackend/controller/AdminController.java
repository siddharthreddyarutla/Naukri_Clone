package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.admin.AdminDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateSignupDto;
import com.peoplehum.naukribackend.dto.candidate.CompleteCandidateDto;
import com.peoplehum.naukribackend.dto.job.JobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import com.peoplehum.naukribackend.serviceImplementation.AdminServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {

    @Autowired
    AdminServiceImplementation adminServiceImplementation;

    @PostMapping("/addAdmin")
    public AdminDto addAdmin(@RequestBody AdminDto adminDto) {
        return adminServiceImplementation.createAdmin(adminDto);
    }

    @PostMapping("/addCandidate")
    public CandidateSignupDto addCandidate(@RequestBody CandidateSignupDto candidateSignupDto) {
        return adminServiceImplementation.addCandidate(candidateSignupDto);
    }

    @GetMapping("/candidate/{candidateId}")
    public CandidateEntity getCandidate(@PathVariable(value = "candidateId") long candidateId) {
        return adminServiceImplementation.getCandidate(candidateId);
    }

    @PutMapping("/editCandidate/{candidateId}")
    public void editCandidate(@PathVariable(value = "candidateId") Long candidateId, @RequestBody CandidateSignupDto candidateSignupDto){
        adminServiceImplementation.updateCandidate(candidateId, candidateSignupDto);
    }

    @DeleteMapping("/{candidateId}")
    public boolean deleteCandidate(@PathVariable(value = "candidateId") long candidateId) {
        return adminServiceImplementation.deleteCandidateProfile(candidateId);
    }

    @GetMapping("/viewAllCandidates")
    public List<CompleteCandidateDto> viewAllCandidates(String role) {
        return adminServiceImplementation.viewCandidates(role);
    }

    @PostMapping("/addRecruiter")
    public RecruiterSignupDto addRecruiter(@RequestBody RecruiterSignupDto recruiterSignupDto) {
        return adminServiceImplementation.addRecruiter(recruiterSignupDto);
    }

    @GetMapping("/getRecruiter/{recruiterId}")
    public RecruiterEntity getRecruiter(@PathVariable(value = "recruiterId") long recruiterId) {
        return adminServiceImplementation.getRecruiter(recruiterId);
    }

    @PutMapping("/editRecruiter/{recruiterId}")
    public void updateRecruiter(@PathVariable(value = "recruiterId") Long recruiterId, @RequestBody RecruiterSignupDto recruiterSignupDto) {
        adminServiceImplementation.updateRecruiter(recruiterId, recruiterSignupDto);
    }

    /* Check this -->
    @DeleteMapping("/deleteRecruiter/{recruiterId}")
    public boolean deleteRecruiter(@PathVariable(value = "recruiterId") Long recruiterId) {
        return adminServiceImplementation.deleteRecruiter(recruiterId);
    }
     */

    @GetMapping("/recruiterList")
    public List<RecruiterSignupDto> viewRecruiters(@RequestParam String role) {
        return adminServiceImplementation.getRecruiterList(role);
    }

    @GetMapping("/jobList")
    public List<JobDto> viewJobs() {
        return adminServiceImplementation.getJobList();
    }
}
