package com.peoplehum.naukribackend.repository.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CandidateRepository extends JpaRepository<CandidateEntity, Long> {
    Optional<CandidateEntity> findById(Long id);

//    List<CandidateEntity> findByNoticePeriod(Integer noticePeriod);

    List<CandidateEntity> findByNoticePeriodLessThan(Integer noticePeriod);
}
