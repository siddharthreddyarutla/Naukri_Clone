package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.candidate.CandidateApplicationDto;
import com.peoplehum.naukribackend.dto.job.*;

import java.util.List;

public interface JobService {
    Long addJob(JobDto jobDto);

    List<JobDto> getJobs();

    void addSkill(Long jobId, List<String> skill);
    void addQualification(Long jobId, List<JobQualificationDto> qualification);

    List<JobPrimaryDto> searchJobs(String designation, Long recruiterId);

    List<JobPrimaryDto> filterJobByAll(String designation, String location, String company);

    List<JobPrimaryDto> filterJobExcludingCompany(String designation, String location);
    List<JobPrimaryDto> filterJobExcludingLocation(String designation, String company);
    List<JobPrimaryDto> filterJobExcludingDesignation(String company, String location);

    List<JobPrimaryDto> filterJobByDesignation(String designation);
    List<JobPrimaryDto> filterJobByCompany(String company);
    List<JobPrimaryDto> filterJobByLocation(String location);

    List<JobPrimaryDto> getPrimaryJobDetails();
    CompleteJobDto getCompleteJobDto(Long jobId);

    void changeJobStatus(CandidateApplicationDto candidateApplicationDto);

    boolean editJob(Long recruiterId, Long jobId, int vacancy);

    JobDetailsDto addJobDetails(JobDetailsDto jobDetailsDto);
}
