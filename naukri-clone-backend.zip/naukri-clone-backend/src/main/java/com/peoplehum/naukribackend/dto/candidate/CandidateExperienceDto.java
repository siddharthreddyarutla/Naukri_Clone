package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateExperienceEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateExperienceDto {
    private double experience;
    private String companyName;
    private String designation;

    public CandidateExperienceEntity toEntity() {
        return CandidateExperienceEntity.builder().experience(experience).companyName(companyName).designation(designation).build();
    }
}
