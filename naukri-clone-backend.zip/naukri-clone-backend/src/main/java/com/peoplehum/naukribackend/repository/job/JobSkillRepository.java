package com.peoplehum.naukribackend.repository.job;

import com.peoplehum.naukribackend.entity.job.JobSkillEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobSkillRepository extends JpaRepository<JobSkillEntity, Long> {
    @Query(
            value = "SELECT JOB_ID FROM job_skill js WHERE js.SKILL = :skill",
            nativeQuery = true)
    List<Long> findBySkill(@Param("skill") String skill);

    List<JobSkillEntity> findByJobId(Long jobId);
}
