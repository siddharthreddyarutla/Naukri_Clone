package com.peoplehum.naukribackend.entity.file;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "file")
public class FileEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long resumeId;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "CANDIDATE_ID")
    private Long candidateId;
}
