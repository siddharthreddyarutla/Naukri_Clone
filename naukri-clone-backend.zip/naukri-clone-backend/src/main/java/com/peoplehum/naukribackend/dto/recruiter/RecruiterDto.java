package com.peoplehum.naukribackend.dto.recruiter;

import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecruiterDto {
    private String company;
    private String designation;

    public RecruiterEntity toEntity() {
        return RecruiterEntity.builder().company(company).designation(designation).build();
    }
}