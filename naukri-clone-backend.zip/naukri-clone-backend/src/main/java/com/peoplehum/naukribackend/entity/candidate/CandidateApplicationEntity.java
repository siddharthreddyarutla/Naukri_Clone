package com.peoplehum.naukribackend.entity.candidate;

import com.peoplehum.naukribackend.dto.candidate.CandidateApplicationDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "candidate_application")
public class CandidateApplicationEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CANDIDATE_ID")
    private Long candidateId;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "STATUS")
    private String status;

    public CandidateApplicationDto toDto() {
        return new CandidateApplicationDto(this.getJobId(), this.getJobId(),this.getStatus());
    }
}
