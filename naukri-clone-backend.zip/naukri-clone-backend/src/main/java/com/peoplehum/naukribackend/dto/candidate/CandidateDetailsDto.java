package com.peoplehum.naukribackend.dto.candidate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateDetailsDto {
    private Long candidateId;
    private List<CandidateQualificationDto> candidateQualificationDtoList;
    private List<CandidateExperienceDto> candidateExperienceDtoList;
    private List<CandidateSkillsDto> candidateSkillsDtoList;
}
