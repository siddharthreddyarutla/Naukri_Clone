package com.peoplehum.naukribackend.repository.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateSkillEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateSkillRepository extends JpaRepository<CandidateSkillEntity, Long> {
    @Query(
            value = "SELECT CANDIDATE_ID FROM candidate_skill s WHERE s.SKILL = :skill",
            nativeQuery = true)
    List<Long> findBySkill(@Param("skill") String skill);

    List<CandidateSkillEntity> findByCandidateId(Long candidateId);
}
