//package com.peoplehum.naukribackend.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//public class SpringConfig {
//    @Autowired
//    private CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
//        httpSecurity.authorizeHttpRequests().antMatchers("/candidate", "/login**")
//                .permitAll()
//                .anyRequest()
//                .authenticated().and().oauth2Login().successHandler(customAuthenticationSuccessHandler);
//        return httpSecurity.build();
//    }
//}
//