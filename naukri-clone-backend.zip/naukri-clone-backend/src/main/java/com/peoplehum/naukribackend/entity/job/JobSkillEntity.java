package com.peoplehum.naukribackend.entity.job;

import com.peoplehum.naukribackend.dto.job.JobSkillDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "job_skill")
public class JobSkillEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "SKILL")
    private String skill;

    public JobSkillDto toDto() {
        return new JobSkillDto(this.getJobId(),this.getSkill());
    }
}
