package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.candidate.*;
import com.peoplehum.naukribackend.serviceImplementation.CandidateServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/candidate")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CandidateController {

    @Autowired
    CandidateServiceImplementation candidateServiceImplementation;

    @PostMapping("/signup")
    public CandidateSignupDto addCandidate(@RequestBody CandidateSignupDto candidateSignupDto) {
        return candidateServiceImplementation.addCandidate(candidateSignupDto);
    }

    @GetMapping("/get")
    public CompleteCandidateDto getCandidate(@RequestParam Long candidateId) {
        return candidateServiceImplementation.getCandidate(candidateId);
    }

    @PutMapping("/editCandidate")
    public CandidateDto editCandidate(@RequestParam Long candidateId, @RequestParam(required = false) String name,
                                      @RequestParam(required = false) String phone, @RequestParam(required = false) String email,
                                      @RequestParam(required = false) Integer noticePeriod, @RequestParam(required = false) String resume,
                                      @RequestParam(required = false) String password, @RequestParam(required = false) String gender)  {
        return candidateServiceImplementation.updateCandidate(candidateId, name, phone, email, noticePeriod, resume, password,gender);
    }

    @PostMapping("/addCandidateDetails")
    public CandidateDetailsDto addDetails(@RequestBody CandidateDetailsDto candidateDetailsDto){
        return candidateServiceImplementation.addCandidateDetails(candidateDetailsDto);
    }

    @PostMapping("/qualifications")
    public void addQualifications(@RequestParam Long candidateId, @RequestBody List<CandidateQualificationDto> candidateQualifications) {
        candidateServiceImplementation.addQualification(candidateId, candidateQualifications);
    }

    @GetMapping("/getQualifications")
    public CandidateQualificationDto getCandidateQualifications(@RequestParam Long candidateId) {
        return candidateServiceImplementation.getCandidateQualifications(candidateId);
    }

    @PostMapping("/experience")
    public void addExperience(@RequestParam Long candidateId, @RequestBody List<CandidateExperienceDto> listOfCandidateExperience) {
        candidateServiceImplementation.addExperience(candidateId, listOfCandidateExperience);
    }

    @GetMapping("/getExperience")
    public CandidateExperienceDto getCandidateExperience(@RequestParam Long candidateId) {
        return candidateServiceImplementation.getCandidateExperience(candidateId);
    }

    @PostMapping("/skill")
    public void addSkills(@RequestParam Long candidateId, @RequestBody List<String> candidateSkills) {
        candidateServiceImplementation.addSkills(candidateId, candidateSkills);
    }

    @DeleteMapping("/delete")
    public boolean deleteCandidateProfile(@RequestParam Long candidateId) {
        return candidateServiceImplementation.deleteCandidateProfile(candidateId);
    }

    @GetMapping("/getCompleteCandidate")
    public CompleteCandidateDto getCompleteCandidate(@RequestParam Long candidateId) {
        return candidateServiceImplementation.getCompleteCandidate(candidateId);
    }
}
