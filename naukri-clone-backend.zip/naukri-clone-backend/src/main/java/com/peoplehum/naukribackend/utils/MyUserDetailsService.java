//package com.peoplehum.naukribackend.utils;
//
//import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
//import com.peoplehum.naukribackend.repository.recruiter.RecruiterRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//@Service
//public class MyUserDetailsService implements UserDetailsService {
//
//    @Autowired
//    private RecruiterRepository recruiterRepository;
//
//    @Override
//    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
//        RecruiterEntity recruiterEntity = recruiterRepository.findByEmail(email);
//
//        if(recruiterEntity==null){
//            throw new UsernameNotFoundException("User 404");
//        }
//
//        return new UserPrincipal(recruiterEntity);
//    }
//
//}