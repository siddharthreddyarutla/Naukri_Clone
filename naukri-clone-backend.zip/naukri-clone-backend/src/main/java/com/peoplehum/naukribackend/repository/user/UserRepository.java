package com.peoplehum.naukribackend.repository.user;

import com.peoplehum.naukribackend.entity.user.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<UserEntity, Long> {
    UserEntity findByEmailAndPassword(String email, String password);

    UserEntity findByEmailAndRole(String recruiterEmail, String recruiter);

    List<UserEntity> findByRole(String role);

    UserEntity findByUserId(Long candidateId);
}
