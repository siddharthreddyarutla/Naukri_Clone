package com.peoplehum.naukribackend.entity.job;

import com.peoplehum.naukribackend.dto.job.CompanyDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "company")
public class CompanyEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String names;

    @Column(name = "ABOUT")
    private String about;

    @Column(name = "STRENGTH")
    private String strength;

    public CompanyDto toDto() {
        return CompanyDto.builder().names(names).about(about).strength(strength).build();
    }
}
