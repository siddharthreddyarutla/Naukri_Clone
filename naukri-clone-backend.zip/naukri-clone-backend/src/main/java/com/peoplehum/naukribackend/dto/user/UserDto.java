package com.peoplehum.naukribackend.dto.user;

import com.peoplehum.naukribackend.entity.user.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private String name;
    private String gender;
    private String phone;
    private String email;
    private String password;
    private String role;

    public UserEntity toEntity() {
        return UserEntity.builder().names(name).gender(gender).phone(phone).email(email).password(password).role(role).build();
    }
}
