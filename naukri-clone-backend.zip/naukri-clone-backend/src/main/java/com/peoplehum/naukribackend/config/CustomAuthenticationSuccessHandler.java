//package com.peoplehum.naukribackend.config;
//
//import org.springframework.security.core.Authentication;
//import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
//import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
//import org.springframework.stereotype.Component;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.util.Map;
//
//@Component
//public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
//
//    @Override
//    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
//                                        Authentication authentication) throws IOException, ServletException {
//
//        // Extract user information from authentication object
//        OAuth2AuthenticationToken oAuth2AuthenticationToken = (OAuth2AuthenticationToken) authentication;
//        Map<String, Object> attributes = oAuth2AuthenticationToken.getPrincipal().getAttributes();
//        String email = (String) attributes.get("email");
//        String name = (String) attributes.get("name");
//        String password = "N/A"; // Github authentication does not provide password
//        System.out.println(email);
//        System.out.println(name);
//        // Save user information in database
//
//        // Redirect user to home page of Angular application
//        response.sendRedirect("http://localhost:4200/");
//    }
//}
//