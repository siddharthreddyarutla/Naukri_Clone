package com.peoplehum.naukribackend.entity.candidate;

import com.peoplehum.naukribackend.dto.candidate.CandidateQualificationDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "candidate_qualification")
public class CandidateQualificationEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CANDIDATE_ID")
    private Long candidateId;

    @Column(name = "EDUCATION_TYPE")
    private String educationType;

    @Column(name = "INSTITUTE")
    private String institute;

    @Column(name = "PERCENTAGE")
    private double percentage;

    public CandidateQualificationDto toDto() {
        return new CandidateQualificationDto(this.getEducationType(),this.getInstitute(),this.getPercentage());
    }
}
