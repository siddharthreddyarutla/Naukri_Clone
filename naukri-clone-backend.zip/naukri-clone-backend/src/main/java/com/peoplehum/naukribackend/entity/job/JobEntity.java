package com.peoplehum.naukribackend.entity.job;

import com.peoplehum.naukribackend.dto.job.JobDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="job")
public class JobEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "JOB_ID")
    private Long id;

    @Column(name = "COMPANY")
    private String company;

    @Column(name = "DESIGNATION")
    private String designation;

    @Column(name = "DOJ")
    private Date doj;

    @Column(name = "POSTING_DATE")
    private Date posting_date;

    @Column(name = "VACANCY")
    private int vacancy;

    @Column(name = "APPLICANTS")
    private int applicants;

    @Column(name = "RECRUITER_ID")
    private Long recruiterId;

    @Column(name = "LOCATION")
    private String location;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "EXPIRY_DATE")
    private Date expiryDate;

    @Column(name = "MIN_EXPERIENCE")
    private int minExperience;

    @Column(name = "MAX_EXPERIENCE")
    private int maxExperience;

    @Column(name = "CTC")
    private double ctc;

    @Column(name = "VISIBILITY")
    private Boolean visibility;

    public JobDto toDto() {
        return new JobDto(this.getCompany(),this.getDesignation(),this.getDoj(),
                this.getPosting_date(),this.getVacancy(),this.getRecruiterId(),
                this.getLocation(),this.getDescription(),this.getExpiryDate(),this.getMinExperience(),this.getMaxExperience(),this.getCtc(),this.getVisibility());
    }
}
