package com.peoplehum.naukribackend.entity.candidate;

import com.peoplehum.naukribackend.dto.candidate.CandidateExperienceDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "candidate_experience")
public class CandidateExperienceEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CANDIDATE_ID")
    private Long candidateId;

    @Column(name = "EXPERIENCE")
    private double experience;

    @Column(name = "COMPANY_NAME")
    private String companyName;

    @Column(name = "DESIGNATION")
    private String designation;

    public CandidateExperienceDto toDto() {
        return new CandidateExperienceDto(this.getExperience(),this.getCompanyName(),this.getDesignation());
    }
}
