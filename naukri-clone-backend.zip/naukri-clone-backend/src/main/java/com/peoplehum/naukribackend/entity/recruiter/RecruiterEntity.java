package com.peoplehum.naukribackend.entity.recruiter;

import com.peoplehum.naukribackend.dto.recruiter.RecruiterDto;
import lombok.*;
import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="recruiter")
public class RecruiterEntity {
    @Id
    @Column(name = "RECRUITER_ID")
    private Long recruiterId;

    @Column(name = "COMPANY")
    private String company;

    @Column(name = "DESIGNATION")
    private String designation;

    public RecruiterDto toDto() {
        return RecruiterDto.builder().company(company).designation(designation).build();
    }
}