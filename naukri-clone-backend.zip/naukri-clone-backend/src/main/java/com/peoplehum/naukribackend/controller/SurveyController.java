package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.job.SurveyJobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSurveyDto;
import com.peoplehum.naukribackend.serviceImplementation.SurveyServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/survey")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SurveyController {

    @Autowired
    SurveyServiceImplementation surveyServiceImplementation;

    @GetMapping("/checkRecruiter")
    public boolean checkRecruiter(@RequestParam String recruiterEmail) {
        System.out.println(recruiterEmail);
        return surveyServiceImplementation.checkRecruiter(recruiterEmail);
    }

    @PostMapping("/surveyRecruiterSignup")
    public void monkeyRecruiterSignup(@RequestBody RecruiterSurveyDto recruiterMonkeyDto) {
        surveyServiceImplementation.surveyRecruiterSignup(recruiterMonkeyDto);
    }

    @PostMapping("/surveyPostJob")
    public void surveyPostJob(@RequestBody SurveyJobDto surveyJobDto) {
        System.out.println(surveyJobDto);
        surveyServiceImplementation.surveyPostJob(surveyJobDto);
    }
}
