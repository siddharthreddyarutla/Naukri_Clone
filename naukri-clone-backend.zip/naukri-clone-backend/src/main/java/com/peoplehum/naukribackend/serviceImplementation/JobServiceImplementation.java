package com.peoplehum.naukribackend.serviceImplementation;

import com.peoplehum.naukribackend.dto.candidate.CandidateApplicationDto;
import com.peoplehum.naukribackend.dto.job.*;
import com.peoplehum.naukribackend.entity.job.JobQualificationEntity;
import com.peoplehum.naukribackend.entity.job.JobSkillEntity;
import com.peoplehum.naukribackend.repository.job.JobQualificationRepository;
import com.peoplehum.naukribackend.repository.job.JobRepository;
import com.peoplehum.naukribackend.repository.job.JobSkillRepository;
import com.peoplehum.naukribackend.service.JobService;
import com.peoplehum.naukribackend.entity.job.JobEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@EnableScheduling
@Service
public class JobServiceImplementation implements JobService {

    @Autowired
    JobRepository jobRepository;
    @Autowired
    JobSkillRepository jobSkillRepository;
    @Autowired
    JobQualificationRepository jobQualificationRepository;

    public JobPrimaryDto createJobPrimaryDto(Long jobId) {
        Optional<JobEntity> jobEntity = jobRepository.findById(jobId);

        if(jobEntity.isPresent()) {
            JobPrimaryDto jobPrimaryDto = new JobPrimaryDto();

            jobPrimaryDto.setJobId(jobEntity.get().getId());
            jobPrimaryDto.setRecruiterId(jobEntity.get().getRecruiterId());
            jobPrimaryDto.setDesignation(jobEntity.get().getDesignation());
            jobPrimaryDto.setDoj(jobEntity.get().getDoj());
            jobPrimaryDto.setLocation(jobEntity.get().getLocation());
            jobPrimaryDto.setVacancy(jobEntity.get().getVacancy());
            jobPrimaryDto.setCompany(jobEntity.get().getCompany());

            return jobPrimaryDto;
        }
        return null;
    }

    @Override
    public Long addJob(JobDto jobDto) {
        JobEntity jobEntity = jobDto.toEntity();
        jobEntity.setVisibility(true);
        jobRepository.save(jobEntity);
        return jobEntity.getId();
    }

    @Override
    public List<JobDto> getJobs() {
        List<JobEntity> entityList = jobRepository.findAll();
        List<JobDto> list = new ArrayList<>();
        for(JobEntity je : entityList) {
            list.add(je.toDto());
        }
        return list;
    }

    @Override
    public void addSkill(Long jobId, List<String> skill) {
        for(String sk : skill) {
            JobSkillDto jobSkillDto = new JobSkillDto(jobId, sk);
            JobSkillEntity jobSkillEntity = jobSkillDto.toEntity();
            jobSkillRepository.save(jobSkillEntity);
        }
    }

    @Override
    public void addQualification(Long jobId, List<JobQualificationDto> qualification) {
        for(JobQualificationDto jq : qualification) {
            JobQualificationEntity jobQualificationEntity = jq.toEntity();
            jobQualificationEntity.setJobId(jobId);
            jobQualificationRepository.save(jobQualificationEntity);
        }
    }

    @Override
    public List<JobPrimaryDto> filterJobByAll(String designation, String location, String company) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByDesignationAndCompanyAndLocation(designation, company, location);

        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobExcludingCompany(String designation, String location) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByDesignationAndLocation(designation, location);
        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobExcludingLocation(String designation, String company) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByDesignationAndCompany(designation, company);
        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobExcludingDesignation(String company, String location) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByCompanyAndLocation(company, location);
        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobByDesignation(String designation) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByDesignation(designation);
        for(JobEntity je : list) {
            Long id = je.getId();
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(id);
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobByLocation(String location) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByLocation(location);
        for(JobEntity je : list) {
            Long id = je.getId();
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(id);
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<JobPrimaryDto> filterJobByCompany(String company) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByCompany(company);

        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

//    @Override
//    public List<JobPrimaryDto> filterJobBySkill(String designation, String skill) {
//        List<JobEntity> list = jobRepository.findByDesignation(designation);
//
//
//        List<JobEntity> finalList = new ArrayList<>();
//        List<Long> list = jobSkillRepository.findBySkill(skill);
//        for(Long job_id : list) {
//            Optional<JobEntity> jobEntity =jobRepository.findById(job_id);
//            finalList.add(jobEntity.get());
//        }
//        return finalList;
//
//        return null;
//    }

    @Override
    public CompleteJobDto getCompleteJobDto(Long jobId) {

        CompleteJobDto completeJobDto = new CompleteJobDto();
        Optional<JobEntity> jobEntity = jobRepository.findById(jobId);

        if(jobEntity.isPresent()) {
            completeJobDto.setCompany(jobEntity.get().getCompany());
            completeJobDto.setDesignation(jobEntity.get().getDesignation());
            completeJobDto.setDoj(jobEntity.get().getDoj());
            completeJobDto.setVacancy(jobEntity.get().getVacancy());
            completeJobDto.setApplicants(jobEntity.get().getApplicants());
            completeJobDto.setPosting_date(jobEntity.get().getPosting_date());
            completeJobDto.setRecruiterId(jobEntity.get().getRecruiterId());
            completeJobDto.setLocation(jobEntity.get().getLocation());
            completeJobDto.setDescription(jobEntity.get().getDescription());
            completeJobDto.setExpiryDate(jobEntity.get().getExpiryDate());
            completeJobDto.setMinExperience(jobEntity.get().getMinExperience());
            completeJobDto.setMaxExperience(jobEntity.get().getMaxExperience());
        }

        List<String> skills = new ArrayList<>();
        List<JobSkillEntity> skillList = jobSkillRepository.findByJobId(jobId);
        for(JobSkillEntity jbs : skillList) {
            skills.add(jbs.getSkill());
        }
        completeJobDto.setSkill(skills);

        List<JobQualificationDto> qualifications = new ArrayList<>();
        List<JobQualificationEntity> qualificationList = jobQualificationRepository.findByJobId(jobId);
        for(JobQualificationEntity jbq : qualificationList) {
            JobQualificationDto jobQualificationDto = new JobQualificationDto(jbq.getJobId(), jbq.getQualification(), jbq.getPercentage());
            qualifications.add(jobQualificationDto);
        }
        completeJobDto.setQualification(qualifications);

        return completeJobDto;
    }

    @Override
    public List<JobPrimaryDto> getPrimaryJobDetails() {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findAll();

        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            if(je.getVisibility())
                finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public void changeJobStatus(CandidateApplicationDto candidateApplicationDto) {
//        CandidateApplicationEntity candidateApplicationEntity = candidateApplicationRepository.findByJobIdAndCandidateId(candidateApplicationDto.getJobId(), candidateApplicationDto.getCandidateId());
//        if(candidateApplicationDto.getStatus().equals("accepted")) {
//            Optional<JobEntity> jobEntity = jobRepository.findById(candidateApplicationDto.getJobId());
//            if(jobEntity.isPresent()) {
//                jobEntity.get().setVacancy(jobEntity.get().getVacancy() - 1);
//                jobRepository.save(jobEntity.get());
//
//                if(jobEntity.get().getVacancy() == 0) {
//                    recruiterServiceImplementation.closeJob(jobEntity.get().getId());
//                }
//            }
//        }
//        candidateApplicationEntity.setStatus(candidateApplicationDto.getStatus());
//        candidateApplicationRepository.save(candidateApplicationEntity);
    }

    @Override
    public boolean editJob(Long recruiterId, Long jobId, int vacancy) {
        Optional<JobEntity> jobEntity = jobRepository.findById(jobId);
        if(jobEntity.isPresent()) {
            if(!Objects.equals(jobEntity.get().getRecruiterId(), recruiterId)) return false;
            jobEntity.get().setVacancy(vacancy);
            jobRepository.save(jobEntity.get());
            return true;
        }
        return false;
    }

    @Override
    public JobDetailsDto addJobDetails(JobDetailsDto jobDetailsDto) {

        JobEntity jobEntity = new JobEntity();
        jobEntity.setId(jobDetailsDto.getJobId());

        if(jobDetailsDto.getJobQualificationDtoList().size() > 0) {
            for(JobQualificationDto jq: jobDetailsDto.getJobQualificationDtoList()) {
                JobQualificationEntity jobQualificationEntity = jq.toEntity();
                jobQualificationRepository.save(jobQualificationEntity);
            }
        }

        if(jobDetailsDto.getJobSkillDtoList().size() > 0) {
            for(JobSkillDto jk: jobDetailsDto.getJobSkillDtoList()) {
                JobSkillEntity jobSkillEntity = jk.toEntity();
                jobSkillRepository.save(jobSkillEntity);
            }
        }
        return jobDetailsDto;
    }

    @Override
    public List<JobPrimaryDto> searchJobs(String designation, Long recruiterId) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findByDesignationAndRecruiterId(designation, recruiterId);
        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = createJobPrimaryDto(je.getId());
            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Scheduled(cron = "0 0 0 * * *")
    public List<JobEntity> findExpiredJobs() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        List<JobEntity> jobEntityList = jobRepository.findAllByExpiryDate(date);
        for(JobEntity je : jobEntityList) {
            je.setVisibility(false);
            jobRepository.save(je);
        }
//        if(jobDto.getStartDate() != null && !surveyDto.getStartDate().equals(dateFormat.format(date)))
        return jobRepository.findByExpiryDate(date);
    }
}