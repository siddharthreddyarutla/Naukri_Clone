package com.peoplehum.naukribackend.dto.admin;

import com.peoplehum.naukribackend.entity.admin.AdminEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminDto {
    private String names;
    private String email;
    private String password;
    public AdminEntity toEntity() {
        return AdminEntity.builder().names(names).email(email).password(password).build();
    }
}
