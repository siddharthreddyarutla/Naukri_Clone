package com.peoplehum.naukribackend.repository.course;

import com.peoplehum.naukribackend.entity.course.NaukriCourseResponseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NaukriCourseRepository extends JpaRepository<NaukriCourseResponseEntity, Long> {
    List<NaukriCourseResponseEntity> findAllByCourseId(Long courseId);
}
