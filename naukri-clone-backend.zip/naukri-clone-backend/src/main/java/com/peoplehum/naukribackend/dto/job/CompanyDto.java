package com.peoplehum.naukribackend.dto.job;

import com.peoplehum.naukribackend.entity.job.CompanyEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDto {

    private String names;
    private String about;
    private String strength;

    public CompanyEntity toEntity() {
        return CompanyEntity.builder().names(names).about(about).strength(strength).build();
    }
}
