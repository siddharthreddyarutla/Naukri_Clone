package com.peoplehum.naukribackend.dto.candidate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateAppliedJobs {
    private Long candidateId;
    private Long jobId;
    private String status;
    private String company;
    private String designation;
    private String location;
    private Date doj;
}
