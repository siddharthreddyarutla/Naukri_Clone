package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.course.NaukriCourseResponseDto;
import com.peoplehum.naukribackend.dto.course.NaukriCourseRequestDto;

import java.io.IOException;
import java.util.List;

public interface CourseraService {
    List<NaukriCourseResponseDto> searchCourses(NaukriCourseRequestDto naukriCourseRequestDto) throws IOException;

    List<NaukriCourseResponseDto> selectedCoursesForAJob(Long jobId, List<NaukriCourseResponseDto> naukriCourseResponseDtoList);
}
