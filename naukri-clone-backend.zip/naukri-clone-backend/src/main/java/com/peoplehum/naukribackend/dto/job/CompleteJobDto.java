package com.peoplehum.naukribackend.dto.job;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CompleteJobDto {
    private String company;
    private String designation;
    private Date doj;
    private Date posting_date;
    private int vacancy;
    private int applicants;
    private Long recruiterId;
    private String location;
    private String description;
    private Date expiryDate;
    private int minExperience;
    private int maxExperience;
    private List<String> skill;
    private List<JobQualificationDto> qualification;
}
