package com.peoplehum.naukribackend.entity.candidate;

import com.peoplehum.naukribackend.dto.candidate.CandidateSkillsDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "candidate_skill")
public class CandidateSkillEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CANDIDATE_ID")
    private Long candidateId;

    @Column(name = "SKILL")
    private String skill;

    public CandidateSkillsDto toDto() {
        return new CandidateSkillsDto(this.getSkill());
    }
}
