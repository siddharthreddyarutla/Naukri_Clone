package com.peoplehum.naukribackend.dto.job;

import com.peoplehum.naukribackend.entity.job.JobSkillEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobSkillDto {
    private Long jobId;
    private String skill;

    public JobSkillEntity toEntity() {
        return JobSkillEntity.builder().jobId(jobId).skill(skill).build();
    }
}
