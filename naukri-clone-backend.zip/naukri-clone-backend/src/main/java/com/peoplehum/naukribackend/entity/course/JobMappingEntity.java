package com.peoplehum.naukribackend.entity.course;

import com.peoplehum.naukribackend.dto.course.JobMappingDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "job_mapping")
public class JobMappingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "COURSE_ID")
    private Long courseId;

    @Column(name = "SURVEY")
    private String surveyLink;

    public JobMappingDto toDto() {
        return JobMappingDto.builder().jobId(jobId).courseId(courseId).surveyLink(surveyLink).build();
    }
}
