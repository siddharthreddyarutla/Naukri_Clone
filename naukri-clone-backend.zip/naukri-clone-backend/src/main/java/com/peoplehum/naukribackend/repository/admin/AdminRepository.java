package com.peoplehum.naukribackend.repository.admin;

import com.peoplehum.naukribackend.entity.admin.AdminEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<AdminEntity, Long> {
}
