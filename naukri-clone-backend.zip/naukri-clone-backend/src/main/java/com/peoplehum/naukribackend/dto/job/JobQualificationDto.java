package com.peoplehum.naukribackend.dto.job;

import com.peoplehum.naukribackend.entity.job.JobQualificationEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobQualificationDto {
    private Long jobId;
    private String qualification;
    private double percentage;

    public JobQualificationEntity toEntity() {
        return JobQualificationEntity.builder().jobId(jobId).qualification(qualification).percentage(percentage).build();
    }
}
