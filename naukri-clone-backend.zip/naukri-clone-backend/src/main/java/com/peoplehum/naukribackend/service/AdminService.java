package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.admin.AdminDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateSignupDto;
import com.peoplehum.naukribackend.dto.candidate.CompleteCandidateDto;
import com.peoplehum.naukribackend.dto.job.JobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;

import java.util.List;

public interface AdminService {
    AdminDto createAdmin(AdminDto adminDto);

    CandidateSignupDto addCandidate(CandidateSignupDto CandidateSignupDto);

    CandidateEntity getCandidate(long candidateId);

    void updateCandidate(Long candidateId, CandidateSignupDto candidateSignupDto);

    boolean deleteCandidateProfile(long candidateId);

    List<CompleteCandidateDto> viewCandidates(String role);

    RecruiterSignupDto addRecruiter(RecruiterSignupDto recruiterSignupDto);

    RecruiterEntity getRecruiter(long recruiterId);

    void updateRecruiter(Long recruiterId, RecruiterSignupDto recruiterSignupDto);

    List<RecruiterSignupDto> getRecruiterList(String role);

    List<JobDto> getJobList();
}
