package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateDto {

    private int noticePeriod;
    private String resume;

    public CandidateEntity toEntity() {
        return CandidateEntity.builder().noticePeriod(noticePeriod).resume(resume).build();
    }
}
