package com.peoplehum.naukribackend.repository.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateQualificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CandidateQualificationRepository extends JpaRepository<CandidateQualificationEntity, Long> {
    List<CandidateQualificationEntity> findByCandidateId(Long candidateId);
}
