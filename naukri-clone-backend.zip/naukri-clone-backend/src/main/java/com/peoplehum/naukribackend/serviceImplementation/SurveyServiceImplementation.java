package com.peoplehum.naukribackend.serviceImplementation;

import com.peoplehum.naukribackend.dto.course.JobMappingDto;
import com.peoplehum.naukribackend.dto.job.JobDto;
import com.peoplehum.naukribackend.dto.job.JobQualificationDto;
import com.peoplehum.naukribackend.dto.job.JobSkillDto;
import com.peoplehum.naukribackend.dto.job.SurveyJobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSurveyDto;
import com.peoplehum.naukribackend.entity.job.CompanyEntity;
import com.peoplehum.naukribackend.entity.job.JobEntity;
import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import com.peoplehum.naukribackend.entity.user.UserEntity;
import com.peoplehum.naukribackend.repository.course.JobMappingRepository;
import com.peoplehum.naukribackend.repository.job.CompanyRepository;
import com.peoplehum.naukribackend.repository.job.JobQualificationRepository;
import com.peoplehum.naukribackend.repository.job.JobRepository;
import com.peoplehum.naukribackend.repository.job.JobSkillRepository;
import com.peoplehum.naukribackend.repository.recruiter.RecruiterRepository;
import com.peoplehum.naukribackend.repository.user.UserRepository;
import com.peoplehum.naukribackend.service.SurveyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SurveyServiceImplementation implements SurveyService {

    @Autowired
    UserRepository userRepository;
    @Autowired
    RecruiterRepository recruiterRepository;
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    JobRepository jobRepository;
    @Autowired
    JobSkillRepository jobSkillRepository;
    @Autowired
    JobQualificationRepository jobQualificationRepository;
    @Autowired
    JobMappingRepository jobMappingRepository;

    @Override
    public boolean checkRecruiter(String recruiterEmail) {
        UserEntity userEntity = userRepository.findByEmailAndRole(recruiterEmail, "recruiter");
        if(userEntity != null) {
            Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(userEntity.getUserId());
            return recruiterEntity.isPresent();
        }
        return false;
    }

    @Override
    public void surveyRecruiterSignup(RecruiterSurveyDto recruiterSurveyDto) {
        UserEntity userEntity = new UserEntity();
        RecruiterEntity recruiterEntity = new RecruiterEntity();
        CompanyEntity companyEntity = new CompanyEntity();

        userEntity.setNames(recruiterSurveyDto.getNames());
        userEntity.setGender(recruiterSurveyDto.getGender());
        userEntity.setPhone(recruiterSurveyDto.getPhone());
        userEntity.setEmail(recruiterSurveyDto.getEmail());
        userEntity.setPassword(recruiterSurveyDto.getPassword());
        userEntity.setRole("recruiter");
        userRepository.save(userEntity);

        recruiterEntity.setRecruiterId(userEntity.getUserId());
        recruiterEntity.setDesignation(recruiterSurveyDto.getDesignation());
        recruiterEntity.setCompany(recruiterSurveyDto.getCompany());
        recruiterRepository.save(recruiterEntity);

        companyEntity.setNames(recruiterSurveyDto.getCompany());
        companyEntity.setAbout(recruiterSurveyDto.getAboutCompany());
        companyEntity.setStrength(recruiterSurveyDto.getStrength());
        companyRepository.save(companyEntity);
    }

    @Override
    public void surveyPostJob(SurveyJobDto surveyJobDto) {

        UserEntity userEntity = userRepository.findByEmailAndRole(surveyJobDto.getRecruiterEmail(), "recruiter");
        Long recruiterId = userEntity.getUserId();
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);

        JobDto jobDto = new JobDto();
        jobDto.setDoj(surveyJobDto.getDoj());
        jobDto.setLocation(surveyJobDto.getLocation());
        jobDto.setDesignation(surveyJobDto.getJobDesignation());
        jobDto.setDescription(surveyJobDto.getDescription());
        jobDto.setCtc(surveyJobDto.getCtc());
        jobDto.setExpiryDate(surveyJobDto.getExpiryDate());
        jobDto.setPosting_date(surveyJobDto.getPosting_date());
        jobDto.setVacancy(surveyJobDto.getVacancy());
        jobDto.setLocation(surveyJobDto.getLocation());
        jobDto.setMinExperience(surveyJobDto.getMinExperience());
        jobDto.setMaxExperience(surveyJobDto.getMaxExperience());
        jobDto.setVisibility(true);
        jobDto.setRecruiterId(recruiterId);
        recruiterEntity.ifPresent(entity -> jobDto.setCompany(entity.getCompany()));

        JobEntity jobEntity = jobDto.toEntity();
        jobRepository.save(jobEntity);

        List<String> skills = surveyJobDto.getSkill();
        for(String skill : skills) {
            JobSkillDto jobSkillDto = new JobSkillDto();
            jobSkillDto.setJobId(jobEntity.getId());
            jobSkillDto.setSkill(skill);

            jobSkillRepository.save(jobSkillDto.toEntity());
        }

        List<JobQualificationDto> qualifications = surveyJobDto.getQualification();
        for(JobQualificationDto jqd : qualifications) {
            JobQualificationDto jobQualificationDto = new JobQualificationDto();
            jobQualificationDto.setJobId(jobEntity.getId());
            jobQualificationDto.setQualification(jqd.getQualification());
            jobQualificationDto.setPercentage(jqd.getPercentage());

            jobQualificationRepository.save(jobQualificationDto.toEntity());
        }

        JobMappingDto jobMappingDto = new JobMappingDto();
        jobMappingDto.setJobId(jobEntity.getId());
        jobMappingDto.setSurveyLink(surveyJobDto.getSurveyLink());
        jobMappingRepository.save(jobMappingDto.toEntity());
    }
}
