package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.candidate.CandidatePrimaryDto;
import com.peoplehum.naukribackend.dto.job.CompanyDto;
import com.peoplehum.naukribackend.dto.job.CompleteJobDto;
import com.peoplehum.naukribackend.dto.job.JobPrimaryDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterLoginDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.dto.user.UserLoginDto;

import java.util.List;

public interface RecruiterService {
    RecruiterSignupDto addRecruiter(RecruiterSignupDto recruiterSignupDto);

    CompanyDto addCompany(CompanyDto companyDto);

    RecruiterDto updateRecruiter(Long id, String name, String phone, String gender, String company, String email, String designation, String password);

    RecruiterSignupDto getRecruiter(Long recruiterId);

    CompanyDto getCompanyDetails(Long companyId);

    List<CandidatePrimaryDto> searchCandidate(Integer noticePeriod);

//    List<CompleteCandidateDto> searchCandidate(String skill);

//    List<CompleteCandidateDto> searchCandidate(Integer noticePeriod, String skill);

    RecruiterLoginDto recruiterLogin(UserLoginDto userLoginDto);

//    void changeCandidateStatus(String status, Long jobId, Long candidateId);

    boolean deleteRecruiterProfile(Long recruiterId);

    List<JobPrimaryDto> getMyJobs(Long recruiterId);

    CompleteJobDto getCompleteJob(Long jobId);

    CandidatePrimaryDto getPrimaryCandidateDetails(Long candidateId);

    void deleteJobByJobId(Long jobId);

    void closeJob(Long jobId);
}
