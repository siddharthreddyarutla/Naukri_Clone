package com.peoplehum.naukribackend.entity.candidate;

import com.peoplehum.naukribackend.dto.candidate.CandidateDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "candidate")
public class CandidateEntity {
    @Id
    @Column(name = "CANDIDATE_ID")
    private Long candidateId;

    @Column(name = "NOTICE_PERIOD")
    private int noticePeriod;

    @Column(name = "RESUME")
    private String resume;

//    @OneToMany(targetEntity = CandidateExperienceEntity.class, cascade = CascadeType.ALL)
//    @JoinColumn(name = "CANDIDATE_ID", referencedColumnName = "CANDIDATE_ID")
//    private List<CandidateEntity> candidateEntityList;
//
//    @OneToMany(targetEntity = CandidateSkillEntity.class, cascade = CascadeType.ALL)
//    @JoinColumn(name = "CANDIDATE_ID", referencedColumnName = "CANDIDATE_ID")
//    private List<CandidateSkillEntity> candidateSkillList;
//
//    @OneToMany(targetEntity = CandidateQualificationEntity.class, cascade = CascadeType.ALL)
//    @JoinColumn(name = "CANDIDATE_ID", referencedColumnName = "CANDIDATE_ID")
//    private List<CandidateQualificationEntity> candidateQualificationList;
//
//    @OneToMany(targetEntity = CandidateApplicationEntity.class, cascade = CascadeType.ALL)
//    @JoinColumn(name = "CANDIDATE_ID", referencedColumnName = "CANDIDATE_ID")
//    private List<CandidateApplicationEntity> candidateApplicationList;

    public CandidateDto toDto() {
        return CandidateDto.builder().noticePeriod(noticePeriod).resume(resume).build();
    }
}
