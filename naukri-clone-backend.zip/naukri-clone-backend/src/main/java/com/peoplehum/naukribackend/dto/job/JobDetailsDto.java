package com.peoplehum.naukribackend.dto.job;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobDetailsDto {
    private Long jobId;
    private List<JobQualificationDto> jobQualificationDtoList;
    private List<JobSkillDto> jobSkillDtoList;
}
