package com.peoplehum.naukribackend.repository.course;

import com.peoplehum.naukribackend.entity.course.JobMappingEntity;
import com.peoplehum.naukribackend.entity.course.NaukriCourseResponseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JobMappingRepository extends JpaRepository<JobMappingEntity, Long> {
    List<JobMappingEntity> findAllByJobId(Long id);

    Optional<JobMappingEntity> findByJobId(Long jobId);
}
