package com.peoplehum.naukribackend.dto.course;

import com.peoplehum.naukribackend.entity.course.JobMappingEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobMappingDto {
    private Long jobId;
    private Long courseId;
    private String surveyLink;

    public JobMappingEntity toEntity() {
        return JobMappingEntity.builder().jobId(jobId).courseId(courseId).surveyLink(surveyLink).build();
    }
}
