package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateSkillEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateSkillsDto {
    private String skill;

    public CandidateSkillEntity toEntity() {
        return CandidateSkillEntity.builder().skill(skill).build();
    }
}
