package com.peoplehum.naukribackend.dto.candidate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidatePrimaryDto {

    private Long candidateId;
    private String name;
    private String email;
    private String phone;
    private int noticePeriod;
    private List<String> skillList;
    private List<CandidateQualificationDto> candidateQualificationDtoList;
}
