package com.peoplehum.naukribackend.entity.course;

import com.peoplehum.naukribackend.dto.course.NaukriCourseResponseDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "course")
public class NaukriCourseResponseEntity {

    @Id
    @Column(name = "COURSE_ID")
    private Integer courseId;

    @Column(name = "COURSE_NAME")
    private String courseName;

    @Column(name = "INSTRUCTOR_NAME")
    private String instructorName;

    public NaukriCourseResponseDto toDto() {
        return NaukriCourseResponseDto.builder().courseId(courseId).courseName(courseName).instructorName(instructorName).build();
    }
}
