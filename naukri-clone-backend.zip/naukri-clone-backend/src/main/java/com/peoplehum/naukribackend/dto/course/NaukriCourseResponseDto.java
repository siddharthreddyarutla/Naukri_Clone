package com.peoplehum.naukribackend.dto.course;

import com.peoplehum.naukribackend.entity.course.NaukriCourseResponseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NaukriCourseResponseDto {
    private Integer courseId;
    private String courseName;
    private String instructorName;

    public NaukriCourseResponseEntity toEntity() {
        return NaukriCourseResponseEntity.builder().courseId(courseId).courseName(courseName).instructorName(instructorName).build();
    }
}
