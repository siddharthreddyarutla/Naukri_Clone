package com.peoplehum.naukribackend.dto.job;

import com.peoplehum.naukribackend.entity.job.JobEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobDto {
    private String company;
    private String designation;
    private Date doj;
    private Date posting_date;
    private int vacancy;
    private long recruiterId;
    private String location;
    private String description;
    private Date expiryDate;
    private int minExperience;
    private int maxExperience;
    private double ctc;
    private Boolean visibility;

    public JobEntity toEntity() {
        return JobEntity.builder().company(company).designation(designation).doj(doj).posting_date(posting_date).vacancy(vacancy).
                recruiterId(recruiterId).location(location).description(description).expiryDate(expiryDate).minExperience(minExperience).maxExperience(maxExperience).ctc(ctc).visibility(visibility).build();
    }
}