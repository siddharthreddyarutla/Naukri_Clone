//package com.peoplehum.naukribackend.utils;
//
//import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.userdetails.UserDetails;
//
//import java.util.Collection;
//import java.util.Collections;
//
//public class UserPrincipal implements UserDetails {
//    private RecruiterEntity recruiterEntity;
//
//    public UserPrincipal(RecruiterEntity recruiterEntity) {
//        super();
//        this.recruiterEntity = recruiterEntity;
//    }
//
//    @Override
//    public Collection<? extends GrantedAuthority> getAuthorities() {
//
//        return Collections.singleton(new SimpleGrantedAuthority("USER"));
//
//    }
//
//    public String getPassword() {
//        return recruiterEntity.getPassword();
//    }
//
//    public String getUsername() {
//        return recruiterEntity.getEmail();
//    }
//
//    @Override
//    public boolean isAccountNonExpired() {
//        // TODO Auto-generated method stub
//        return true;
//    }
//
//    @Override
//    public boolean isAccountNonLocked() {
//        // TODO Auto-generated method stub
//        return true;
//    }
//
//    @Override
//    public boolean isCredentialsNonExpired() {
//        // TODO Auto-generated method stub
//        return true;
//    }
//
//    @Override
//    public boolean isEnabled() {
//        // TODO Auto-generated method stub
//        return true;
//    }
//
//}