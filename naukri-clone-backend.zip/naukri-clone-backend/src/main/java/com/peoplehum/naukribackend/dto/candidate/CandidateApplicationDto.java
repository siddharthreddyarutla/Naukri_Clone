package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateApplicationEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateApplicationDto {
    private Long candidateId;
    private Long jobId;
    private String status;

    public CandidateApplicationEntity toEntity() {
        return CandidateApplicationEntity.builder().candidateId(candidateId).jobId(jobId).status(status).build();
    }
}
