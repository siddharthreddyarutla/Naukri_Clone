package com.peoplehum.naukribackend.repository.file;

import com.peoplehum.naukribackend.entity.file.FileEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileRepository extends JpaRepository<FileEntity, Long> {
    List<FileEntity> findByCandidateId(String fileName);
}
