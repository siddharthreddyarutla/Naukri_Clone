package com.peoplehum.naukribackend.repository.job;

import com.peoplehum.naukribackend.entity.job.JobQualificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobQualificationRepository extends JpaRepository<JobQualificationEntity, Long> {

    List<JobQualificationEntity> findByJobId(Long jobId);
}
