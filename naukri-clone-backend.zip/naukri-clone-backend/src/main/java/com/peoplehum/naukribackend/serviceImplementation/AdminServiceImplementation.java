package com.peoplehum.naukribackend.serviceImplementation;

import com.peoplehum.naukribackend.dto.admin.AdminDto;
import com.peoplehum.naukribackend.dto.candidate.*;
import com.peoplehum.naukribackend.dto.job.JobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.entity.admin.AdminEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateExperienceEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateQualificationEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateSkillEntity;
import com.peoplehum.naukribackend.entity.job.JobEntity;
import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import com.peoplehum.naukribackend.entity.user.UserEntity;
import com.peoplehum.naukribackend.repository.admin.AdminRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateExperienceRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateQualificationRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateSkillRepository;
import com.peoplehum.naukribackend.repository.job.JobRepository;
import com.peoplehum.naukribackend.repository.recruiter.RecruiterRepository;
import com.peoplehum.naukribackend.repository.user.UserRepository;
import com.peoplehum.naukribackend.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImplementation implements AdminService {

    @Autowired
    AdminRepository adminRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    CandidateRepository candidateRepository;
    @Autowired
    CandidateSkillRepository candidateSkillRepository;
    @Autowired
    CandidateExperienceRepository candidateExperienceRepository;
    @Autowired
    CandidateQualificationRepository candidateQualificationRepository;
    @Autowired
    RecruiterRepository recruiterRepository;
    @Autowired
    JobRepository jobRepository;
    @Override
    public AdminDto createAdmin(AdminDto adminDto) {
        AdminEntity adminEntity = adminDto.toEntity();
        adminRepository.save(adminEntity);
        return adminDto;
    }

    @Override
    public CandidateSignupDto addCandidate(CandidateSignupDto CandidateSignupDto) {
        CandidateEntity candidateEntity = new CandidateEntity();
        UserEntity userEntity = new UserEntity();
        userEntity.setNames(CandidateSignupDto.getNames());
        userEntity.setGender(CandidateSignupDto.getGender());
        userEntity.setPhone(CandidateSignupDto.getPhone());
        userEntity.setEmail(CandidateSignupDto.getEmail());
        userEntity.setPassword(CandidateSignupDto.getPassword());
        userEntity.setRole(CandidateSignupDto.getRole());
        userRepository.save(userEntity);

        candidateEntity.setCandidateId(userEntity.getUserId());
        candidateEntity.setNoticePeriod(CandidateSignupDto.getNoticePeriod());
        candidateEntity.setResume(CandidateSignupDto.getResume());
        candidateRepository.save(candidateEntity);
        return CandidateSignupDto;
    }

    @Override
    public CandidateEntity getCandidate(long candidateId) {
        Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
        return candidateEntity.orElse(null);
    }

    @Override
    public void updateCandidate(Long candidateId, CandidateSignupDto candidateSignupDto) {

        Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
        Optional<UserEntity> userEntity = userRepository.findById(candidateId);

        if(candidateEntity.isPresent() && userEntity.isPresent()) {
            userEntity.get().setNames(candidateSignupDto.getNames());
            userEntity.get().setGender(candidateSignupDto.getGender());
            userEntity.get().setPhone(candidateSignupDto.getPhone());
            candidateEntity.get().setResume(candidateSignupDto.getResume());
            candidateEntity.get().setNoticePeriod(candidateSignupDto.getNoticePeriod());

            candidateRepository.save(candidateEntity.get());
            userRepository.save(userEntity.get());
        }
    }

    @Override
    public boolean deleteCandidateProfile(long candidateId) {
        Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
        if(candidateEntity.isPresent()) {
            candidateRepository.delete(candidateEntity.get());
            return true;
        }
        return false;
    }

    @Override
    public List<CompleteCandidateDto> viewCandidates(String role) {

        List<UserEntity> userEntities = userRepository.findByRole(role);
        List<CompleteCandidateDto> completeCandidateDtos = new ArrayList<>();

        for(UserEntity userEntity: userEntities) {
            Long candidateId = userEntity.getUserId();
            CompleteCandidateDto completeCandidateDto = new CompleteCandidateDto();

            completeCandidateDto.setCandidateId(candidateId);
            completeCandidateDto.setName(userEntity.getNames());
            completeCandidateDto.setGender(userEntity.getGender());
            completeCandidateDto.setPhone(userEntity.getPhone());
            completeCandidateDto.setEmail(userEntity.getEmail());
            completeCandidateDto.setPassword(userEntity.getPassword());

            Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
            if(candidateEntity.isPresent()) {
                completeCandidateDto.setNoticePeriod(candidateEntity.get().getNoticePeriod());
                completeCandidateDto.setResume(candidateEntity.get().getResume());
            }

            List<CandidateSkillEntity> candidateSkillEntities= candidateSkillRepository.findByCandidateId(candidateId);
            List<String> skillList = new ArrayList<>();

            for(CandidateSkillEntity cse: candidateSkillEntities) {
                skillList.add(cse.getSkill());
            }
            completeCandidateDto.setSkill(skillList);

            List<List<CandidateQualificationDto>> qualifications = new ArrayList<>();
            List<CandidateQualificationEntity> qualificationList = candidateQualificationRepository.findByCandidateId(candidateId);
            for(CandidateQualificationEntity cqe : qualificationList) {
                List<CandidateQualificationDto> list = new ArrayList<>();
                list.add(cqe.toDto());
                qualifications.add(list);
            }
            completeCandidateDto.setCandidateQualifications(qualifications);

            List<List<CandidateExperienceDto>> experiences = new ArrayList<>();
            List<CandidateExperienceEntity> experienceList = candidateExperienceRepository.findByCandidateId(candidateId);
            for(CandidateExperienceEntity cee : experienceList) {
                List<CandidateExperienceDto> list = new ArrayList<>();
                list.add(cee.toDto());
                experiences.add(list);
            }
            completeCandidateDto.setCandidateExperiences(experiences);

            completeCandidateDtos.add(completeCandidateDto);
        }

        return completeCandidateDtos;
    }

    @Override
    public RecruiterSignupDto addRecruiter(RecruiterSignupDto recruiterSignupDto) {
        RecruiterEntity recruiterEntity = new RecruiterEntity();
        UserEntity userEntity = new UserEntity();

        userEntity.setNames(recruiterSignupDto.getNames());
        userEntity.setGender(recruiterSignupDto.getGender());
        userEntity.setPhone(recruiterSignupDto.getPhone());
        userEntity.setEmail(recruiterSignupDto.getEmail());
        userEntity.setPassword(recruiterSignupDto.getPassword());
        userEntity.setRole(recruiterSignupDto.getRole());
        userRepository.save(userEntity);

        recruiterEntity.setRecruiterId(userEntity.getUserId());
        recruiterEntity.setDesignation(recruiterSignupDto.getDesignation());
        recruiterEntity.setCompany(recruiterSignupDto.getCompany());
        recruiterRepository.save(recruiterEntity);
        return recruiterSignupDto;
    }

    @Override
    public RecruiterEntity getRecruiter(long recruiterId) {
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);
        return recruiterEntity.orElse(null);
    }

    @Override
    public void updateRecruiter(Long recruiterId, RecruiterSignupDto recruiterSignupDto) {
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);
        Optional<UserEntity> userEntity = userRepository.findById(recruiterId);

        if(recruiterEntity.isPresent() && userEntity.isPresent()) {
            userEntity.get().setNames(recruiterSignupDto.getNames());
            userEntity.get().setGender(recruiterSignupDto.getGender());
            userEntity.get().setPhone(recruiterSignupDto.getPhone());
            recruiterEntity.get().setDesignation(recruiterSignupDto.getDesignation());
            recruiterEntity.get().setCompany(recruiterSignupDto.getCompany());

            recruiterRepository.save(recruiterEntity.get());
            userRepository.save(userEntity.get());
        }
    }

    @Override
    public List<RecruiterSignupDto> getRecruiterList(String role) {
        List<UserEntity> userEntities = userRepository.findByRole(role);
        List<RecruiterSignupDto> recruiterSignupDtoList = new ArrayList<>();

        for(UserEntity userEntity: userEntities) {
            Long recruiterId = userEntity.getUserId();
            RecruiterSignupDto recruiterSignupDto = new RecruiterSignupDto();

            recruiterSignupDto.setNames(userEntity.getNames());
            recruiterSignupDto.setEmail(userEntity.getEmail());
            recruiterSignupDto.setGender(userEntity.getGender());
            recruiterSignupDto.setPhone(userEntity.getPhone());
            recruiterSignupDto.setRole(userEntity.getRole());

            Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);
            if(recruiterEntity.isPresent()) {
                recruiterSignupDto.setCompany(recruiterEntity.get().getCompany());
                recruiterSignupDto.setDesignation(recruiterEntity.get().getDesignation());

                recruiterSignupDtoList.add(recruiterSignupDto);
            }
        }
        return recruiterSignupDtoList;
    }

    @Override
    public List<JobDto> getJobList() {
        List<JobEntity> jobEntities = jobRepository.findAll();
        List<JobDto> jobDtoList = new ArrayList<>();

        for(JobEntity je: jobEntities) {
            jobDtoList.add(je.toDto());
        }

        return jobDtoList;
    }


    /* Check this API -->
    @Override
    public boolean deleteRecruiter(Long recruiterId) {
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);
        Optional<UserEntity> userEntity = userRepository.findById(recruiterId);

        if(recruiterEntity.get() != null) {
            userRepository.delete(userEntity.get());
            recruiterRepository.delete(recruiterEntity.get());
            return true;
        }
        return false;
    }
       */
}