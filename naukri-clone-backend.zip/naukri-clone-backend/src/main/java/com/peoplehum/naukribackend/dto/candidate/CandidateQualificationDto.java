package com.peoplehum.naukribackend.dto.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateQualificationEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateQualificationDto {

    private String educationType;
    private String institute;
    private double percentage;

    public CandidateQualificationEntity toEntity() {
        return CandidateQualificationEntity.builder().educationType(educationType).institute(institute).percentage(percentage).build();
    }
}
