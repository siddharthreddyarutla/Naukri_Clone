package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.candidate.CandidateApplicationDto;
import com.peoplehum.naukribackend.dto.candidate.CandidatePrimaryDto;
import com.peoplehum.naukribackend.dto.job.CompanyDto;
import com.peoplehum.naukribackend.dto.job.CompleteJobDto;
import com.peoplehum.naukribackend.dto.job.JobPrimaryDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.serviceImplementation.JobServiceImplementation;
import com.peoplehum.naukribackend.serviceImplementation.RecruiterServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recruiter")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class RecruiterController {

    @Autowired
    RecruiterServiceImplementation recruiterServiceImplementation;
    @Autowired
    JobServiceImplementation jobServiceImplementation;


    @PostMapping("/signup")
    public RecruiterSignupDto addRecruiter(@RequestBody RecruiterSignupDto recruiterSignupDto) {
        return recruiterServiceImplementation.addRecruiter(recruiterSignupDto);
    }

    @GetMapping("/get")
    public RecruiterSignupDto getRecruiter(@RequestParam Long recruiterId) {
        return recruiterServiceImplementation.getRecruiter(recruiterId);
    }

    @GetMapping("/getJobsPostedByMe")
    public List<JobPrimaryDto> getMyJobs(@RequestParam Long recruiterId){
        return recruiterServiceImplementation.getMyJobs(recruiterId);
    }

    @GetMapping("/getCompleteJob")
    public CompleteJobDto getCompleteJob(@RequestParam Long jobId) {
        return recruiterServiceImplementation.getCompleteJob(jobId);
    }

    @PutMapping("/editRecruiter")
    public RecruiterDto editRecruiter(@RequestParam Long id, @RequestParam(required = false) String name,
                                      @RequestParam(required = false) String phone, @RequestParam(required = false) String gender,
                                      @RequestParam(required = false) String company, @RequestParam(required = false) String email,
                                      @RequestParam(required = false) String designation, @RequestParam(required = false) String password) {
        return recruiterServiceImplementation.updateRecruiter(id, name, phone, gender, company, email, designation, password);
    }

    @PostMapping("/company")
    public CompanyDto addCompany(@RequestBody CompanyDto companyDto) {
        return recruiterServiceImplementation.addCompany(companyDto);
    }

    @GetMapping("/companyDetails")
    public CompanyDto getCompanyDetails(@RequestParam Long companyId) {
        return recruiterServiceImplementation.getCompanyDetails(companyId);
    }

    @GetMapping("/searchCandidate")
    public List<CandidatePrimaryDto> searchCandidate(@RequestParam(required = false) Integer noticePeriod) {
        return recruiterServiceImplementation.searchCandidate(noticePeriod);
    }

    @PutMapping("/changeJobStatus")
    public void changeJobStatus(@RequestBody CandidateApplicationDto candidateApplicationDto) {
        jobServiceImplementation.changeJobStatus(candidateApplicationDto);
    }

    @DeleteMapping("/delete")
    public boolean deleteRecruiterProfile(@RequestParam Long recruiterId) {
        return recruiterServiceImplementation.deleteRecruiterProfile(recruiterId);
    }
    @GetMapping("/primaryCandidateDto/{jobId}")
    public CandidatePrimaryDto getPrimaryCandidateDetails(@PathVariable("jobId") Long jobId) {
        return recruiterServiceImplementation.getPrimaryCandidateDetails(jobId);
    }

    @DeleteMapping("/deleteJob")
    public void deleteJobByJobId(@RequestParam Long jobId) {
        recruiterServiceImplementation.deleteJobByJobId(jobId);
    }

    @GetMapping("/closeJob")
    public void closeJob(@RequestParam Long jobId) {
        recruiterServiceImplementation.closeJob(jobId);
    }
}
