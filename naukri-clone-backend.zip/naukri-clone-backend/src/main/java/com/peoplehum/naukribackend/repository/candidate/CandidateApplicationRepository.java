package com.peoplehum.naukribackend.repository.candidate;

import com.peoplehum.naukribackend.entity.candidate.CandidateApplicationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateApplicationRepository extends JpaRepository<CandidateApplicationEntity, Long> {
    CandidateApplicationEntity findByJobIdAndCandidateId(Long jobId, Long candidateId);

    CandidateApplicationEntity deleteAllById(Long candidateId);

    List<CandidateApplicationEntity> findByJobId(Long jobId);
}
