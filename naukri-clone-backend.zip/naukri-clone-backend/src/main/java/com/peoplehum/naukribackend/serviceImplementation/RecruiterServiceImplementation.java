package com.peoplehum.naukribackend.serviceImplementation;

import com.peoplehum.naukribackend.dto.candidate.CandidatePrimaryDto;
import com.peoplehum.naukribackend.dto.candidate.CandidateQualificationDto;
import com.peoplehum.naukribackend.dto.job.CompleteJobDto;
import com.peoplehum.naukribackend.dto.job.JobPrimaryDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterLoginDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSignupDto;
import com.peoplehum.naukribackend.dto.user.UserLoginDto;
import com.peoplehum.naukribackend.entity.candidate.CandidateApplicationEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateQualificationEntity;
import com.peoplehum.naukribackend.entity.candidate.CandidateSkillEntity;
import com.peoplehum.naukribackend.entity.job.JobEntity;
import com.peoplehum.naukribackend.entity.user.UserEntity;
import com.peoplehum.naukribackend.repository.candidate.CandidateApplicationRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateQualificationRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateRepository;
import com.peoplehum.naukribackend.repository.candidate.CandidateSkillRepository;
import com.peoplehum.naukribackend.repository.job.CompanyRepository;
import com.peoplehum.naukribackend.repository.job.JobRepository;
import com.peoplehum.naukribackend.repository.recruiter.RecruiterRepository;
import com.peoplehum.naukribackend.repository.user.UserRepository;
import com.peoplehum.naukribackend.service.RecruiterService;
import com.peoplehum.naukribackend.dto.job.CompanyDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterDto;
import com.peoplehum.naukribackend.entity.job.CompanyEntity;
import com.peoplehum.naukribackend.entity.recruiter.RecruiterEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RecruiterServiceImplementation implements RecruiterService{

    @Autowired
    RecruiterRepository recruiterRepository;
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    CandidateRepository candidateRepository;
    @Autowired
    CandidateSkillRepository candidateSkillRepository;
    @Autowired
    CandidateApplicationRepository candidateApplicationRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    JobRepository jobRepository;
    @Autowired
    JobServiceImplementation jobServiceImplementation;
    @Autowired
    CandidateQualificationRepository candidateQualificationRepository;

    @Override
    public RecruiterSignupDto addRecruiter(RecruiterSignupDto recruiterSignupDto) {
        UserEntity temp = userRepository.findByEmailAndRole(recruiterSignupDto.getEmail(), "recruiter");
        if(temp != null) return null;

        RecruiterEntity recruiterEntity = new RecruiterEntity();
        UserEntity userEntity = new UserEntity();
        userEntity.setNames(recruiterSignupDto.getNames());
        userEntity.setGender(recruiterSignupDto.getGender());
        userEntity.setPhone(recruiterSignupDto.getPhone());
        userEntity.setEmail(recruiterSignupDto.getEmail());
        userEntity.setPassword(recruiterSignupDto.getPassword());
        userEntity.setRole("recruiter");
        userRepository.save(userEntity);

        recruiterEntity.setRecruiterId(userEntity.getUserId());
        recruiterEntity.setDesignation(recruiterSignupDto.getDesignation());
        recruiterEntity.setCompany(recruiterSignupDto.getCompany());
        recruiterRepository.save(recruiterEntity);
        return recruiterSignupDto;
    }

    @Override
    public CompanyDto addCompany(CompanyDto companyDto) {
        CompanyEntity temp = companyRepository.findByNames(companyDto.getNames());
        if(temp != null) return null;

        CompanyEntity companyEntity = companyDto.toEntity();
        companyRepository.save(companyEntity);
        return companyDto;
    }

    @Override
    public RecruiterDto updateRecruiter(Long recruiterId, String name, String phone, String gender, String company, String email, String designation, String password) {
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);
        Optional<UserEntity> userEntity = userRepository.findById(recruiterId);

        if(userEntity.isPresent() && recruiterEntity.isPresent()) {
            if(name != null) userEntity.get().setNames(name);
            if(phone != null) userEntity.get().setPhone(phone);
            if(gender != null) userEntity.get().setGender(gender);
            if(email != null) userEntity.get().setEmail(email);
            if(password != null) userEntity.get().setPassword(password);
            userRepository.save(userEntity.get());

            if(company != null) recruiterEntity.get().setCompany(company);
            if(designation != null) recruiterEntity.get().setDesignation(designation);
            recruiterRepository.save(recruiterEntity.get());

            return recruiterEntity.get().toDto();
        }
        return null;
    }

    @Override
    public RecruiterSignupDto getRecruiter(Long recruiterId) {
        RecruiterSignupDto recruiterSignupDto = new RecruiterSignupDto();

        Optional<UserEntity> userEntity = userRepository.findById(recruiterId);

        if(userEntity.isPresent()) {
            recruiterSignupDto.setNames(userEntity.get().getNames());
            recruiterSignupDto.setPhone(userEntity.get().getPhone());
            recruiterSignupDto.setEmail(userEntity.get().getEmail());
            recruiterSignupDto.setGender(userEntity.get().getGender());
        }

        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(recruiterId);

        if(recruiterEntity.isPresent()) {
            recruiterSignupDto.setDesignation(recruiterEntity.get().getDesignation());
            recruiterSignupDto.setCompany(recruiterEntity.get().getCompany());
        }

        return recruiterSignupDto;
    }

    @Override
    public CompanyDto getCompanyDetails(Long companyId) {
        Optional<CompanyEntity> companyEntity = companyRepository.findById(companyId);
        return companyEntity.map(CompanyEntity::toDto).orElse(null);
    }

//    @Override
//    public List<CompleteCandidateDto> searchCandidate(Integer noticePeriod, String skill) {
//        List<CompleteCandidateDto> finalList = new ArrayList<>();
//        List<Long> list = candidateSkillRepository.findBySkill(skill);
//        List<Long> ids = new ArrayList<>();
//        for(Long id : list) {
//            Optional<CandidateEntity> candidateEntity = candidateRepository.findById(id);
//            if(candidateEntity.isPresent()) {
//                if(candidateEntity.get().getNoticePeriod() < noticePeriod) {
//                    ids.add(candidateEntity.get().getCandidateId());
//                }
//            }
//        }
//        for(Long id : ids) {
//            finalList.add(candidateServiceImplementation.getCompleteCandidate(id));
//        }
//        return finalList;
//    }

    @Override
    public RecruiterLoginDto recruiterLogin(UserLoginDto userLoginDto) {
        UserEntity userEntity = userRepository.findByEmailAndPassword(userLoginDto.getEmail(), userLoginDto.getPassword());
        if(userEntity == null) return null;
        Optional<RecruiterEntity> recruiterEntity = recruiterRepository.findById(userEntity.getUserId());
        if(recruiterEntity.isPresent()) {
            RecruiterLoginDto recruiterLoginDto = new RecruiterLoginDto();
            recruiterLoginDto.setRecruiterId(userEntity.getUserId());
            recruiterLoginDto.setCompany(recruiterEntity.get().getCompany());
            return recruiterLoginDto;
        }
        return null;
    }

//    @Override
//    public void changeCandidateStatus(String status, Long jobId, Long candidateId) {
//        CandidateApplicationEntity candidateApplicationEntity = candidateApplicationRepository.findByJobIdAndCandidateId(jobId, candidateId);
//        candidateApplicationEntity.setStatus(status);
//        candidateApplicationRepository.save(candidateApplicationEntity);
//    }

    @Override
    public boolean deleteRecruiterProfile(Long recruiterId) {
        recruiterRepository.deleteById(recruiterId);
        return true;
    }

    @Override
    public List<JobPrimaryDto> getMyJobs(Long recruiterId) {
        List<JobPrimaryDto> finalList = new ArrayList<>();
        List<JobEntity> list = jobRepository.findAllByRecruiterId(recruiterId);

        for(JobEntity je : list) {
            JobPrimaryDto jobPrimaryDto = new JobPrimaryDto();

            jobPrimaryDto.setJobId(je.getId());
            jobPrimaryDto.setRecruiterId(je.getRecruiterId());
            jobPrimaryDto.setDesignation(je.getDesignation());
            jobPrimaryDto.setDoj(je.getDoj());
            jobPrimaryDto.setLocation(je.getLocation());
            jobPrimaryDto.setVacancy(je.getVacancy());
            jobPrimaryDto.setCompany(je.getCompany());
            jobPrimaryDto.setApplicants(je.getApplicants());
            jobPrimaryDto.setVisibility(je.getVisibility());

            finalList.add(jobPrimaryDto);
        }
        return finalList;
    }

    @Override
    public List<CandidatePrimaryDto> searchCandidate(Integer noticePeriod) {
        List<CandidatePrimaryDto> finalList = new ArrayList<>();
        List<CandidateEntity> list = candidateRepository.findByNoticePeriodLessThan(noticePeriod);
        for(CandidateEntity ce : list) {
            Long candidateId = ce.getCandidateId();
            Optional<UserEntity> userEntity = userRepository.findById(candidateId);
            CandidatePrimaryDto candidatePrimaryDto = new CandidatePrimaryDto();

            if(userEntity.isPresent()) {
                candidatePrimaryDto.setCandidateId(candidateId);
                candidatePrimaryDto.setName(userEntity.get().getNames());
                candidatePrimaryDto.setPhone(userEntity.get().getPhone());
                candidatePrimaryDto.setEmail(userEntity.get().getEmail());
                candidatePrimaryDto.setNoticePeriod(ce.getNoticePeriod());
                finalList.add(candidatePrimaryDto);
            }
        }
        return finalList;
    }

//    @Override
//    public List<CompleteCandidateDto> searchCandidate(String skill) {
//        List<CompleteCandidateDto> finalList = new ArrayList<>();
//        List<Long> list = candidateSkillRepository.findBySkill(skill);
//        for(Long id : list) {
//            finalList.add(candidateServiceImplementation.getCompleteCandidate(id));
//        }
//        return finalList;
//    }

    @Override
    public CompleteJobDto getCompleteJob(Long jobId) {
        return jobServiceImplementation.getCompleteJobDto(jobId);
    }

    @Override
    public CandidatePrimaryDto getPrimaryCandidateDetails(Long jobId) {

        List<CandidateApplicationEntity> candidateApplicationEntities = candidateApplicationRepository.findByJobId(jobId);

        CandidatePrimaryDto candidatePrimaryDto = new CandidatePrimaryDto();
        for(CandidateApplicationEntity cae: candidateApplicationEntities) {
            Long candidateId = cae.getCandidateId();
            Optional<UserEntity> userEntity = userRepository.findById(candidateId);
            if(userEntity.isPresent()) {
                candidatePrimaryDto.setCandidateId(candidateId);
                candidatePrimaryDto.setName(userEntity.get().getNames());
                candidatePrimaryDto.setEmail(userEntity.get().getEmail());
                candidatePrimaryDto.setPhone(userEntity.get().getPhone());
            }

            Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
            candidateEntity.ifPresent(entity -> candidatePrimaryDto.setNoticePeriod(entity.getNoticePeriod()));

            List<String> candidateSkills = new ArrayList<>();
            List<CandidateSkillEntity> candidateSkillEntity = candidateSkillRepository.findByCandidateId(candidateId);
            for(CandidateSkillEntity cse: candidateSkillEntity) {
                candidateSkills.add(cse.getSkill());
            }
            candidatePrimaryDto.setSkillList(candidateSkills);

            List<CandidateQualificationDto> qualificationDtoList = new ArrayList<>();
            List<CandidateQualificationEntity> candidateQualificationEntity = candidateQualificationRepository.findByCandidateId(candidateId);

            for(CandidateQualificationEntity cqe : candidateQualificationEntity) {
                qualificationDtoList.add(cqe.toDto());
            }
            candidatePrimaryDto.setCandidateQualificationDtoList(qualificationDtoList);
        }
        return candidatePrimaryDto;
    }

    @Override
    public void deleteJobByJobId(Long jobId) {
        Optional<JobEntity> jobEntity = jobRepository.findById(jobId);
        if(jobEntity.isPresent()) {
            jobRepository.deleteById(jobId);
        }
    }

    @Override
    public void closeJob(Long jobId) {
        Optional<JobEntity> jobEntity = jobRepository.findById(jobId);
        if(jobEntity.isPresent()) {
            jobEntity.get().setVisibility(false);
            System.out.println(jobEntity);
            jobRepository.save(jobEntity.get());
        }
    }
}
