package com.peoplehum.naukribackend.service;

import com.peoplehum.naukribackend.dto.job.SurveyJobDto;
import com.peoplehum.naukribackend.dto.recruiter.RecruiterSurveyDto;

public interface SurveyService {
    boolean checkRecruiter(String recruiterEmail);

    void surveyRecruiterSignup(RecruiterSurveyDto recruiterMonkeyDto);

    void surveyPostJob(SurveyJobDto surveyJobDto);
}
