package com.peoplehum.naukribackend.serviceImplementation;

import com.google.gson.Gson;
import com.peoplehum.naukribackend.dto.candidate.*;
import com.peoplehum.naukribackend.dto.job.CompanyDto;
import com.peoplehum.naukribackend.dto.user.UserLoginDto;
import com.peoplehum.naukribackend.entity.candidate.*;
import com.peoplehum.naukribackend.entity.course.NaukriCourseResponseEntity;
import com.peoplehum.naukribackend.entity.course.JobMappingEntity;
import com.peoplehum.naukribackend.entity.job.CompanyEntity;
import com.peoplehum.naukribackend.entity.job.JobEntity;
import com.peoplehum.naukribackend.entity.user.UserEntity;
import com.peoplehum.naukribackend.repository.candidate.*;
import com.peoplehum.naukribackend.repository.course.NaukriCourseRepository;
import com.peoplehum.naukribackend.repository.course.JobMappingRepository;
import com.peoplehum.naukribackend.repository.job.CompanyRepository;
import com.peoplehum.naukribackend.repository.job.JobRepository;
import com.peoplehum.naukribackend.repository.user.UserRepository;
import com.peoplehum.naukribackend.service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class CandidateServiceImplementation implements CandidateService {

    @Autowired
    CandidateRepository candidateRepository;
    @Autowired
    CandidateQualificationRepository candidateQualificationRepository;
    @Autowired
    CandidateExperienceRepository candidateExperienceRepository;
    @Autowired
    CandidateApplicationRepository candidateApplicationRepository;
    @Autowired
    CandidateSkillRepository candidateSkillRepository;
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    JobRepository jobRepository;
    @Autowired
    JobMappingRepository jobMappingRepository;
    @Autowired
    NaukriCourseRepository naukriCourseRepository;

    @Override
    public CandidateSignupDto addCandidate(CandidateSignupDto candidateSignupDto) {
        UserEntity temp = userRepository.findByEmailAndRole(candidateSignupDto.getEmail(), "candidate");
        if (temp != null) return null;

        CandidateEntity candidateEntity = new CandidateEntity();
        UserEntity userEntity = new UserEntity();
        userEntity.setNames(candidateSignupDto.getNames());
        userEntity.setGender(candidateSignupDto.getGender());
        userEntity.setPhone(candidateSignupDto.getPhone());
        userEntity.setEmail(candidateSignupDto.getEmail());
        userEntity.setPassword(candidateSignupDto.getPassword());
        userEntity.setRole(candidateSignupDto.getRole());
        userRepository.save(userEntity);

        candidateEntity.setCandidateId(userEntity.getUserId());
        candidateEntity.setNoticePeriod(candidateSignupDto.getNoticePeriod());
        candidateEntity.setResume(candidateSignupDto.getResume());
        candidateRepository.save(candidateEntity);
        return candidateSignupDto;
    }

    @Override
    public void addQualification(Long candidateId, List<CandidateQualificationDto> listOfCandidateQualifications) {

        for (CandidateQualificationDto cq : listOfCandidateQualifications) {
            CandidateQualificationEntity candidateQualificationEntity = cq.toEntity();
            candidateQualificationEntity.setCandidateId(candidateId);
            candidateQualificationRepository.save(candidateQualificationEntity);
        }
    }

    @Override
    public void addExperience(Long candidateId, List<CandidateExperienceDto> listOfCandidateExperience) {
        for (CandidateExperienceDto ce : listOfCandidateExperience) {
            CandidateExperienceEntity candidateExperienceEntity = ce.toEntity();
            candidateExperienceEntity.setCandidateId(candidateId);
            candidateExperienceRepository.save(candidateExperienceEntity);
        }
    }

    @Override
    public SurveyDto applyJob(CandidateApplicationDto candidateApplicationDto) throws IOException {

        SurveyDto surveyDto = new SurveyDto();
        CandidateApplicationEntity candidateApplicationEntity = candidateApplicationRepository.findByJobIdAndCandidateId(candidateApplicationDto.getJobId(), candidateApplicationDto.getCandidateId());
        if (candidateApplicationEntity == null) {
            Optional<JobEntity> jobEntity = jobRepository.findById(candidateApplicationDto.getJobId());
            if (jobEntity.isPresent()) {
                Optional<JobMappingEntity> jobMappingEntity = jobMappingRepository.findByJobId(candidateApplicationDto.getJobId());
                if (jobMappingEntity.isPresent()) {
                    System.out.println(jobMappingEntity.get());
                    if (jobMappingEntity.get().getSurveyLink().isEmpty()) {
                        System.out.println("called apply course job");
                        surveyDto.setLink(applyToCourseraJob(candidateApplicationDto, jobMappingEntity.get(), jobEntity.get()));
                    }
                    else {
                        System.out.println("Fill the form");
                        surveyDto.setLink(applyToSurveyJob(candidateApplicationDto, jobMappingEntity.get(), jobEntity.get()));
                    }
                }
                else{
                    jobEntity.get().setApplicants(jobEntity.get().getApplicants() + 1);
                    jobRepository.save(jobEntity.get());

                    candidateApplicationEntity = candidateApplicationDto.toEntity();
                    candidateApplicationEntity.setJobId(candidateApplicationDto.getJobId());
                    candidateApplicationRepository.save(candidateApplicationEntity);
                    surveyDto.setLink("applied successfully");
                }
            }
        }
        return surveyDto;
    }

    public String applyToSurveyJob(CandidateApplicationDto candidateApplicationDto, JobMappingEntity jobMappingEntity, JobEntity jobEntity) throws IOException {

        String surveyLink = jobMappingEntity.getSurveyLink();
//        System.out.println(surveyLink);
        String url = "http://172.16.29.144:8091/surveyLink";

        CandidateApplicationEntity candidateApplicationEntity = candidateApplicationDto.toEntity();
        candidateApplicationEntity.setJobId(candidateApplicationDto.getJobId());
        candidateApplicationRepository.save(candidateApplicationEntity);

        return url;
    }

    public String applyToCourseraJob(CandidateApplicationDto candidateApplicationDto, JobMappingEntity jobMappingEntity, JobEntity jobEntity) throws IOException {

        String url = "http://172.16.29.141:8091/candidate/check/courseStatus";
        Optional<UserEntity> userEntity = Optional.ofNullable(userRepository.findByUserId(candidateApplicationDto.getCandidateId()));
        String candidateEmail = userEntity.get().getEmail();

        System.out.println("URL: " + url + "?candidateEmail=" + candidateEmail);

        List<Long> listOfCourseIds = new ArrayList<>();
        List<JobMappingEntity> naukriCourseResponseEntityList = jobMappingRepository.findAllByJobId(jobEntity.getId());
        for(JobMappingEntity jme : naukriCourseResponseEntityList) {
            Long courseId = jme.getCourseId();
            listOfCourseIds.add(courseId);
        }
        System.out.println(listOfCourseIds);

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<List<Long>> entity = new HttpEntity<>(listOfCourseIds, headers);
        ResponseEntity<Void> response = restTemplate.postForEntity(url + "?candidateEmail=" + candidateEmail, entity, Void.class);

//        restTemplate = null;

        HttpStatus statusCode = response.getStatusCode();
        System.out.println("HTTP status: " + statusCode);

//        if (statusCode == HttpStatus.OK) {
//            jobEntity.setApplicants(jobEntity.getApplicants() + 1);
//            jobRepository.save(jobEntity);
//
//            CandidateApplicationEntity candidateApplicationEntity = candidateApplicationDto.toEntity();
//            candidateApplicationEntity.setJobId(candidateApplicationDto.getJobId());
//            candidateApplicationRepository.save(candidateApplicationEntity);
//        }
//        else if (statusCode == HttpStatus.NOT_FOUND) {
//            System.out.println("Redirect to coursera sign up page");
////            String redirectUrl = "http:172.16.144.141:4042";
//        }
//        else {
//            System.out.println("redirect to incomplete course page");
////            String redirectUrl = "http:172.16.144.141:4042";
//        }

        return null;
    }

    @Override
    public List<CandidateAppliedJobs> getJobsByCandidateId(Long candidateId) {
        List<CandidateApplicationEntity> appliedJobsList = candidateApplicationRepository.findAll();
        List<CandidateAppliedJobs> list = new ArrayList<>();
        for(CandidateApplicationEntity cae : appliedJobsList) {
            if(Objects.equals(cae.getCandidateId(), candidateId)) {
                CandidateAppliedJobs candidateAppliedJobs = new CandidateAppliedJobs();
                candidateAppliedJobs.setCandidateId(cae.getCandidateId());
                candidateAppliedJobs.setStatus(cae.getStatus());
                candidateAppliedJobs.setJobId(cae.getJobId());

                Optional<JobEntity> jobEntity = jobRepository.findById(cae.getJobId());
                if(jobEntity.isPresent()) {
                    candidateAppliedJobs.setCompany(jobEntity.get().getCompany());
                    candidateAppliedJobs.setDesignation(jobEntity.get().getDesignation());
                    candidateAppliedJobs.setLocation(jobEntity.get().getLocation());
                    candidateAppliedJobs.setDoj(jobEntity.get().getDoj());
                    list.add(candidateAppliedJobs);
                }
            }
        }
        System.out.println(list);
        return list;
    }

    @Override
    public CandidateDto updateCandidate(Long candidateId, String names, String phone, String email, Integer noticePeriod, String resume, String password, String gender) {

        Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);
        Optional<UserEntity> userEntity = userRepository.findById(candidateId);

        if(candidateEntity.isPresent() && userEntity.isPresent()) {
            if(names != null) userEntity.get().setNames(names);
            if(phone != null) userEntity.get().setPhone(phone);
            if(email != null) userEntity.get().setEmail(email);
            if(noticePeriod != null) candidateEntity.get().setNoticePeriod(noticePeriod);
            if(resume != null) candidateEntity.get().setResume(resume);
            if(password != null) userEntity.get().setPassword(password);
            if(gender != null) userEntity.get().setGender(gender);

            candidateRepository.save(candidateEntity.get());
            userRepository.save(userEntity.get());
            return candidateEntity.get().toDto();
        }

        return null;
    }

    @Override
    public void addSkills(Long candidateId, List<String> skill) {

        for(String sk : skill) {
            CandidateSkillsDto candidateSkillDto = new CandidateSkillsDto(sk);
            CandidateSkillEntity candidateSkillEntity = candidateSkillDto.toEntity();
            candidateSkillEntity.setCandidateId(candidateId);
            candidateSkillRepository.save(candidateSkillEntity);
        }
    }

    @Override
    public CompleteCandidateDto getCandidate(Long candidateId) {
        return getCompleteCandidate(candidateId);
    }

    @Override
    public CompanyDto getCompanyDetails(String company) {
        CompanyEntity companyEntity = companyRepository.findByNames(company);
        return companyEntity.toDto();
    }

    @Override
    public Long candidateLogin(UserLoginDto userLoginDto) {
        UserEntity userEntity = userRepository.findByEmailAndPassword(userLoginDto.getEmail(), userLoginDto.getPassword());
        System.out.println(userEntity);
        if(userEntity == null) return null;
        else return userEntity.getUserId();
    }

    @Override
    public CandidateQualificationDto getCandidateQualifications(Long candidateId) {
        Optional<CandidateQualificationEntity> candidateQualificationEntity = candidateQualificationRepository.findById(candidateId);
        return candidateQualificationEntity.map(CandidateQualificationEntity::toDto).orElse(null);
    }

    @Override
    public CandidateExperienceDto getCandidateExperience(Long candidateId) {
        Optional<CandidateExperienceEntity> candidateExperienceEntity = candidateExperienceRepository.findById(candidateId);
        return candidateExperienceEntity.map(CandidateExperienceEntity::toDto).orElse(null);
    }

    @Override
    public boolean deleteCandidateProfile(Long candidateId) {
        userRepository.deleteById(candidateId);
        return true;
    }

    @Override
    public CompleteCandidateDto getCompleteCandidate(Long candidateId) {
        CompleteCandidateDto completeCandidateDto = new CompleteCandidateDto();
        Optional<UserEntity> userEntity = userRepository.findById(candidateId);
        Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateId);

        if(userEntity.isPresent() && candidateEntity.isPresent()) {
            completeCandidateDto.setName(userEntity.get().getNames());
            completeCandidateDto.setGender(userEntity.get().getGender());
            completeCandidateDto.setPhone(userEntity.get().getPhone());
            completeCandidateDto.setEmail(userEntity.get().getEmail());
            completeCandidateDto.setPassword(userEntity.get().getPassword());
            completeCandidateDto.setResume(candidateEntity.get().getResume());
            completeCandidateDto.setNoticePeriod(candidateEntity.get().getNoticePeriod());
        }

        List<String> skills = new ArrayList<>();
        List<CandidateSkillEntity> skillList = candidateSkillRepository.findByCandidateId(candidateId);
        for(CandidateSkillEntity cse : skillList) {
            skills.add(cse.getSkill());
        }
        completeCandidateDto.setSkill(skills);

        List<List<CandidateQualificationDto>> qualifications = new ArrayList<>();
        List<CandidateQualificationEntity> qualificationList = candidateQualificationRepository.findByCandidateId(candidateId);
        for(CandidateQualificationEntity cqe : qualificationList) {
            List<CandidateQualificationDto> list = new ArrayList<>();
            list.add(cqe.toDto());
            qualifications.add(list);
        }
        completeCandidateDto.setCandidateQualifications(qualifications);

        List<List<CandidateExperienceDto>> experiences = new ArrayList<>();
        List<CandidateExperienceEntity> experienceList = candidateExperienceRepository.findByCandidateId(candidateId);
        for(CandidateExperienceEntity cee : experienceList) {
            List<CandidateExperienceDto> list = new ArrayList<>();
            list.add(cee.toDto());
            experiences.add(list);
        }
        completeCandidateDto.setCandidateExperiences(experiences);
        return completeCandidateDto;
    }

    @Override
    public CandidateDetailsDto addCandidateDetails(CandidateDetailsDto candidateDetailsDto) {

        CandidateEntity candidateEntity = new CandidateEntity();
        candidateEntity.setCandidateId(candidateDetailsDto.getCandidateId());

        if(candidateDetailsDto.getCandidateSkillsDtoList().size() > 0) {
            for(CandidateSkillsDto cs : candidateDetailsDto.getCandidateSkillsDtoList()) {
                CandidateSkillEntity candidateSkillEntity = cs.toEntity();
                candidateSkillRepository.save(candidateSkillEntity);
            }
        }

        if(candidateDetailsDto.getCandidateQualificationDtoList().size() > 0) {
            for(CandidateQualificationDto cq: candidateDetailsDto.getCandidateQualificationDtoList()) {
                CandidateQualificationEntity candidateQualificationEntity = cq.toEntity();
                candidateQualificationRepository.save(candidateQualificationEntity);
            }
        }

        if(candidateDetailsDto.getCandidateExperienceDtoList().size() > 0) {
            for(CandidateExperienceDto ce: candidateDetailsDto.getCandidateExperienceDtoList()) {
                CandidateExperienceEntity candidateExperienceEntity = ce.toEntity();
                candidateExperienceRepository.save(candidateExperienceEntity);
            }
        }
        return candidateDetailsDto;
    }
}

