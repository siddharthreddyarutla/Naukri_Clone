package com.peoplehum.naukribackend.controller;

import com.peoplehum.naukribackend.dto.recruiter.RecruiterLoginDto;
import com.peoplehum.naukribackend.dto.user.UserLoginDto;
import com.peoplehum.naukribackend.serviceImplementation.CandidateServiceImplementation;
import com.peoplehum.naukribackend.serviceImplementation.RecruiterServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AuthController {

    @Autowired
    CandidateServiceImplementation candidateServiceImplementation;
    @Autowired
    RecruiterServiceImplementation recruiterServiceImplementation;

    @PostMapping("/candidateLogin")
    public Long candidateLogin(@RequestBody UserLoginDto userLoginDto) {
        return candidateServiceImplementation.candidateLogin(userLoginDto);
    }

    @PostMapping("/recruiterLogin")
    public RecruiterLoginDto recruiterLogin(@RequestBody UserLoginDto userLoginDto) {
        return recruiterServiceImplementation.recruiterLogin(userLoginDto);
    }
}