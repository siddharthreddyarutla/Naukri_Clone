CREATE TABLE IF NOT EXISTS admin (
    ID bigint NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'primary key',
    NAME VARCHAR(255) NOT NULL COMMENT 'admin name',
    EMAIL VARCHAR(255) NOT NULL COMMENT 'admin email',
    PASSWORD VARCHAR(255) NOT NULL COMMENT 'admin login password',
    UNIQUE KEY `idx_candidate_email_constraint` (`EMAIL`)
);